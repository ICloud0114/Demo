// components/popupwindow/popupwindow.js
//备注：父布局如果可能会滑动，请使用scroll-view,而不要使用view
var onSure = null
var onCancel = null
var onDismiss = null

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isShow: {
      type: Boolean,
      value: false,
    },
    isCommon: {
      type: Boolean,
      value: true
    },
    popData: {
      type: Object,
      value: {
        title: '',
        needTitle: true,
        content: '',
        isSingleBtn: false,
        cancelText: '取消',
        sureText: '确定'
      }
    },
  },

  /**
   * 组件的初始数据
   */
  data: {},

  /**
   * 组件的方法列表
   */
  methods: {
    noScrollMove: function () {},
    noTap: function () {},
    showPop: function (popData, sureCallback, cancelCallback, dismissCallback) {
      if (popData !== undefined) {
        this.data.popData = popData
      }
      this.setData({
        isShow: true,
        popData: this.data.popData
      })
      onCancel = cancelCallback
      onSure = sureCallback
      onDismiss = dismissCallback
    },
    dismissPop: function () {
      this.setData({
        isShow: false
      })
      if (onDismiss !== undefined && onDismiss != null) {
        onDismiss()
      }
    },
    cancel: function (res) {
      this.dismissPop()
      if (onCancel !== undefined && onCancel != null) {
        onCancel(res)
      }
    },
    sure: function (res) {
      this.dismissPop()
      if (onSure !== undefined && onSure != null) {
        onSure(res)
      }
    }
  }
})