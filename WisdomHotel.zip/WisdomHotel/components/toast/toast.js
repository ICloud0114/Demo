// components/toast/toast.js
//备注：父布局如果可能会滑动，请使用scroll-view,而不要使用view

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isShow: {
      type: Boolean,
      value: false,
    },
    toastText: {
      type: String,
      value: ''
    },
    position: {
      type: String,
      value: 'center'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {},

  /**
   * 组件的方法列表
   */
  methods: {
    noScrollMove: function () {},
    noTap: function () {},
    //显示Toast
    show(toastText) {
      this.setData({
        isShow: true,
        toastText: toastText
      })
      setTimeout(() => {
        this.setData({
          isShow: false,
          toastText: ""
        })
      }, 2 * 1000)
    }
  }
})