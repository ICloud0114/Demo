// components/loading/loading.js
//备注：父布局如果可能会滑动，请使用scroll-view,而不要使用view

var _animation; // 动画实体
var _animationIndex = 0; // 动画执行次数index（当前执行了多少次）
var _animationIntervalId = -1; // 动画定时任务id，通过setInterval来达到无限旋转，记录id，用于结束定时任务
const _ANIMATION_TIME = 500; // 动画播放一次的时长ms

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isShow: {
      type: Boolean,
      value: false,
    },
    showText: {
      type: Boolean,
      value: true
    },
    loadingText: {
      type: String,
      value: '加载中...'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    rotateAnimData: {}
  },

  /**
   * 组件的方法列表
   */
  methods: {
    noScrollMove: function () {},
    noTap: function () {},
    dismissLoading: function () {
      this.stopAnimationInterval()
      this.setData({
        isShow: false
      })
    },
    showLoading() {
      _animation = wx.createAnimation({
        duration: _ANIMATION_TIME,
        timingFunction: 'linear',
      })
      this.startAnimationInterval()
      this.setData({
        isShow: true
      })
    },
    /**
     * 实现image旋转动画，每次旋转 120*n度
     */
    rotateAni: function (n) {
      _animation.rotate(120 * (n)).step()
      this.setData({
        rotateAnimData: _animation.export()
      })
    },

    /**
     * 开始旋转
     */
    startAnimationInterval: function () {
      var that = this;
      that.rotateAni(++_animationIndex); // 进行一次旋转
      _animationIntervalId = setInterval(function () {
        that.rotateAni(++_animationIndex);
      }, _ANIMATION_TIME); // 每间隔_ANIMATION_TIME进行一次旋转
    },

    /**
     * 停止旋转
     */
    stopAnimationInterval: function () {
      if (_animationIntervalId > 0) {
        clearInterval(_animationIntervalId);
        _animationIntervalId = 0;
      }
    },
  },
})