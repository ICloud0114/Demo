//app.js
var currentVersion = null

App({
  onLaunch: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        console.log("屏幕相关信息==>" + JSON.stringify(res))
        that.appData.screenWidth = res.screenWidth;
        that.appData.prRatio = 750.00 / res.windowWidth
        that.appData.screenHeight = res.safeArea.bottom * that.appData.prRatio;
        that.appData.windowHeight = res.windowHeight * that.appData.prRatio;
        currentVersion = res.SDKVersion;
        //获取ActionBar的高度
        let info = wx.getMenuButtonBoundingClientRect() //胶囊控件的信息
        that.appData.actionBarHeight = (info.bottom + info.top - res.statusBarHeight) * that.appData.prRatio
        console.log("页面信息==>宽度：" + that.appData.screenWidth + '\n高度：' + that.appData.screenHeight + "\n内容窗口(除ActionBar和NavigationBar)的高度：" + that.appData.windowHeight + '\npr/rpx比值：' + that.appData.prRatio + '\nActionBar的高度为：' + that.appData.actionBarHeight)
      }
    })
  },
  appData: {
    screenWidth: 0, //单位为px
    screenHeight: 0, //单位为rpx
    windowHeight: 0, //单位为rpx(除ActionBar和TabBar的剩余高度)
    actionBarHeight: 0, //单位为rpx
    prRatio: 1,

    userInfo: null, //用户信息
    szRegionList: null //深圳的行政区列表
  },
  isHightVersion: function (baseVersion) {
    if (currentVersion == null) {
      return false
    }
    let currVer = currentVersion.split('.')
    let baseVer = baseVersion.split('.')
    const len = Math.max(currVer.length, baseVer.length)

    while (currVer.length < len) {
      currVer.push('0')
    }
    while (baseVer.length < len) {
      baseVer.push('0')
    }

    for (let i = 0; i < len; i++) {
      const num1 = parseInt(currVer[i])
      const num2 = parseInt(baseVer[i])

      if (num1 > num2) {
        return true
      } else if (num1 < num2) {
        return false
      }
    }
    return true
  },
  getNickName: function () {
    let userInfo = this.appData.userInfo
    if (userInfo == null) {
      return ''
    } else {
      let nickName = userInfo.userName
      if (nickName === undefined || nickName == null || nickName.length <= 0) {
        let phone = userInfo.mob
        if (phone === undefined || phone == null || phone.length <= 0) {
          return ''
        } else {
          return phone
        }
      } else {
        return nickName
      }
    }
  },
  getAvatarUrl: function () {
    let userInfo = this.appData.userInfo
    if (userInfo == null) {
      return ''
    } else {
      let avatarUrl = userInfo.avatarUrl
      if (avatarUrl === undefined || avatarUrl == null || avatarUrl.length <= 0) {
        return 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_avatar120.png'
      } else {
        return avatarUrl
      }
    }
  }
})