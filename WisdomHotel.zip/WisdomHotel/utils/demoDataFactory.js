//是否启用Demo数据
export const userDemoData = false
// 用户信息
export const userInfo = {
  userId: 'u001',
  userName: '小兵',
  mob: '17674031627',
  avatarUrl: ''
}
//酒店列表
export const hotelList = {
  total: 5,
  rows: [{
      hotelNo: 'h001', //酒店编号
      hotelName: '深圳宝安维多利亚五星级豪华皇庭酒店', //酒店名称
      level: '七星级', //酒店评级
      detailedAddress: '深圳市宝安区石岩街道梨园工业区拓邦工业园宿舍', //酒店地址
      longitude: 113.913245, //经度
      latitude: 22.668304, //纬度
      imagePath: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel1.png', //酒店图片路径
      originalPrice: 1680.98, //最低价房型原价
      vipPrice: 998.98 //最低价房型会员价
    },
    {
      hotelNo: 'h002',
      hotelName: '拓邦酒店',
      level: '18星级',
      detailedAddress: '深圳拓邦工业园宿舍-2',
      longitude: 113.913245,
      latitude: 22.668304,
      imagePath: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel2.png',
      originalPrice: 16800.98,
      vipPrice: 9980.98
    },
    {
      hotelNo: 'h003',
      hotelName: '拓邦宾馆',
      level: '18星级',
      detailedAddress: '深圳拓邦工业园宿舍-3',
      longitude: 113.913245,
      latitude: 22.668304,
      imagePath: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel2.png',
      originalPrice: 16800.98,
      vipPrice: 9980.98
    },
    {
      hotelNo: 'h004',
      hotelName: '拓邦宾馆-2',
      level: '18星级',
      detailedAddress: '深圳拓邦工业园宿舍-3',
      longitude: 113.913245,
      latitude: 22.668304,
      imagePath: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel2.png',
      originalPrice: 16800.98,
      vipPrice: 9980.98
    },
    {
      hotelNo: 'h005',
      hotelName: '拓邦宾馆-3',
      level: '18星级',
      detailedAddress: '深圳拓邦工业园宿舍-3',
      longitude: 113.913245,
      latitude: 22.668304,
      imagePath: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel2.png',
      originalPrice: 16800.98,
      vipPrice: 9980.98
    }
  ]
}

/**
 * 地区数组
 */
export const areasList = [{
  "id": "440303",
  "name": "罗湖区"
}, {
  "id": "440304",
  "name": "福田区"
}, {
  "id": "440305",
  "name": "南山区"
}, {
  "id": "440306",
  "name": "宝安区"
}, {
  "id": "440307",
  "name": "龙岗区"
}, {
  "id": "440308",
  "name": "盐田区"
}, {
  "id": "440309",
  "name": "龙华区"
}, {
  "id": "440310",
  "name": "坪山区"
}, {
  "id": "440311",
  "name": "光明区"
}]

//酒店详情
export const hotelDetail = {
  hotelNo: 'hn001', //酒店编号
  imgUrls: "http://internal-file.topband-cloud.com/topband/wisdomhotel/details_image_hotel.png,http://internal-file.topband-cloud.com/topband/wisdomhotel/details_image_hotel.png,http://internal-file.topband-cloud.com/topband/wisdomhotel/details_image_hotel.png", //酒店图片列表，字符串数组，每个元素代表一张图片的完整路径,
  hotelName: '深圳宝安维多利亚五星级豪华皇庭酒店', //酒店名称
  phone: '13838381438', //酒店电话
  level: '18', //酒店评级
  detailedAddress: '深圳市福田区深南大道1003号', //酒店地址
  longitude: 113.913680, //经度
  latitude: 22.667814, //纬度
  detail: '我们这个酒店相当的好使，都快来住啊。住一晚，神清气爽，烦恼全消;住两晚美容养颜，容光焕发。住得越多好处越多啊。', //酒店详情/政策
  facilities: '空调，电视，电脑，桌椅，沙发啥的，应有尽有啊', //酒店设施
  roomList: [{
      roomId: 'f001', //房型id
      roomType: '双人间', //房型
      roomStyle: '高级大床房', //房间风格
      imgUrls: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel3.png', //房型图片列表，多图片路径逗号分隔
      originalPrice: 16800.98, //原价
      vipPrice: 998.98, //会员价
    },
    {
      roomId: 'f002',
      roomType: '单人间',
      roomStyle: '豪华总统房',
      imgUrls: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel3.png',
      originalPrice: 16800.98,
      vipPrice: 998.98,
    },
    {
      roomId: 'f003',
      roomType: '三人间',
      roomStyle: '平民舒适房',
      imgUrls: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel3.png',
      originalPrice: 16800.98,
      vipPrice: 998.98,
    }
  ]
}

//我的订单列表
export const myOrderList = {
  total: 2,
  rows: [{
      orderNo: 'o001', //订单编号
      hotelName: '深圳宝安维多利亚五星级豪华皇庭酒店', //酒店名称
      hotelImg: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel1.png', //酒店图片
      roomType: '高级大床房', //房型
      originalPrice: '16800.98', //原价
      vipPrice: '9980.98', //会员价
      money: 100.00, //定金
      startTime: '2020-06-28' //入住时间格式YYYY-MM-dd
    },
    {
      orderNo: 'o002',
      hotelName: '拓邦宿舍',
      hotelImg: 'http://internal-file.topband-cloud.com/topband/wisdomhotel/home_image_hotel1.png',
      roomType: '高级大床房',
      originalPrice: '16800.98',
      vipPrice: '9980.98',
      money: 100.00,
      startTime: '2020-06-28'
    },
  ]
}

//常用信息（联系人列表）
export const contactList = [{
    id: 'c001', //联系人id
    linkman: '独孤无敌', //联系人姓名
    mob: '13838389438', //联系人手机
    idCard: '741741741741741741', //联系人身份证号
  },
  {
    id: 'c002',
    linkman: '易水寒',
    mob: '13838385438',
    idCard: '741741741741741741',
  },
  {
    id: 'c003',
    linkman: '第五轻柔',
    mob: '13838387438',
    idCard: '741741741741741741',
  },
  {
    id: 'c004', //联系人id
    linkman: '独孤无敌', //联系人姓名
    mob: '13838389438', //联系人手机
    idCard: '741741741741741741', //联系人身份证号
  },
  {
    id: 'c005',
    linkman: '易水寒',
    mob: '13838385438',
    idCard: '741741741741741741',
  },
  {
    id: 'c006',
    linkman: '第五轻柔',
    mob: '13838387438',
    idCard: '741741741741741741',
  },
  {
    id: 'c007', //联系人id
    linkman: '独孤无敌', //联系人姓名
    mob: '13838389438', //联系人手机
    idCard: '741741741741741741', //联系人身份证号
  },
  {
    id: 'c008',
    linkman: '易水寒',
    mob: '13838385438',
    idCard: '741741741741741741',
  },
  {
    id: 'c009',
    linkman: '第五轻柔',
    mob: '13838387438',
    idCard: '741741741741741741',
  }
]