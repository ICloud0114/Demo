/**
 * 格式化的日期字符串（yyyy-MM-dd）
 * @param {日期对象} date 
 * @param {年偏移量} offSetYears 
 */
export const formatTime = (date, offSetYears) => {
  let year = offSetYears != undefined ? date.getFullYear() + offSetYears : date.getFullYear()
  let month = date.getMonth() + 1
  let day = date.getDate()

  return [year, month, day].map(formatNumber).join('-')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

/**
 * 获取日期对应的星期数
 * @param {日期对象} date 
 */
export const formatWeek = date => {
  let week = date.getDay();
  let show_day = new Array('周日', '周一', '周二', '周三', '周四', '周五', '周六');

  return show_day[week]
}

/**
 * 获取显示日期时间（mm月dd日）
 * @param {日期对象} date 
 */
export const formatShowTime = (date) => {
  let month = date.getMonth() + 1
  let day = date.getDate()
  return formatNumber(month) + '月' + formatNumber(day) + '日'
}

/**
 * 获取当前的时分时间
 */
export const currentFormatTime = () => {
  let currentDate = new Date()
  let hours = currentDate.getHours()
  let minutes = currentDate.getMinutes()
  return formatNumber(hours) + ':' + formatNumber(minutes)
}