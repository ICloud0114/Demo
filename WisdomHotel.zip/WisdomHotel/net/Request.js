const Api = require("./Api")
const DemoDataFactory = require("../utils/demoDataFactory")

const LOADING_TIME = 1 * 1000

/**
 * 请求后响应成功
 * @param {请求api} api 
 * @param {请求响应} response 
 * @param {成功回调} successCallback 
 * @param {失败回调} failureCallback 
 */
function responseSuccess(api, response, successCallback, failureCallback) {
  if (response.data.status === 0) {
    console.log(api + "==>请求成功：" + JSON.stringify(response.data.data))
    successCallback(response.data.data)
  } else {
    console.log(api + "==>请求失败：" + JSON.stringify(response))
    failureCallback({
      errorCode: response.data.status,
      errorMsg: response.data.message
    })
  }
}

/**
 * 请求后响应失败
 * @param {请求api} api 
 * @param {错误消息类} errMsg 
 */
function responseFailure(api, errMsg, failureCallback) {
  console.log(api + "==>请求失败：" + JSON.stringify(errMsg))
  failureCallback({
    errorCode: -1,
    errorMsg: '请求失败'
  })
}


// =========================================非登录状态的首页和其详情请求 start==============================================
/**
 * 获取非登录状态下的推荐酒店列表
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getHotelListUnlogin(successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.hotelList)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.HOTEL_LIST_UNLOGIN
    console.log("请求url为==>" + url)
    wx.request({
      method: Api.POST,
      url: url,
      data: {
        pageNumber: 1,
        pageSize: 1000
      },
      success(data) {
        responseSuccess(Api.HOTEL_LIST_UNLOGIN, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.HOTEL_LIST_UNLOGIN, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取非登录状态下的酒店详情
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getHotelDetailUnlogin(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.hotelDetail)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.HOTEL_DETAIL_UNLOGIN
    console.log("请求url为==>" + url)
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      data: params,
      success(data) {
        responseSuccess(Api.HOTEL_DETAIL_UNLOGIN, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.HOTEL_DETAIL_UNLOGIN, errMsg, failureCallback)
      }
    })
  }
}
// =========================================非登录状态的首页和其详情请求 end==============================================



// =========================================登录相关请求 start==============================================
/**
 * 微信用户一键登录
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function wxUserOneKeyLogin(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.WX_AUTH_PHONE_LOGIN
    console.log("请求url为==>" + url)
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      data: params,
      success(data) {
        if (data.data.status === 0) {
          Api.setAccessToken(data.data.data.token)
          Api.setRefreshToken(data.data.data.refreshToken)
          //获取用户信息
          getUserInfo({}, successCallback, failureCallback)
        } else {
          responseSuccess(Api.WX_AUTH_PHONE_LOGIN, data, successCallback, failureCallback)
        }
      },
      fail(errMsg) {
        responseFailure(Api.WX_AUTH_PHONE_LOGIN, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 手机号验证登录
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function phoneVerifyLogin(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.PHONE_LOGIN
    console.log("请求url为==>" + url)
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      data: params,
      success(data) {
        if (data.data.status === 0) {
          Api.setAccessToken(data.data.data.token)
          Api.setRefreshToken(data.data.data.refreshToken)
          //获取用户信息
          getUserInfo({}, successCallback, failureCallback)
        } else {
          responseSuccess(Api.PHONE_LOGIN, data, successCallback, failureCallback)
        }
      },
      fail(errMsg) {
        responseFailure(Api.PHONE_LOGIN, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取手机验证码
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getVerificationCode(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.GET_VERIFICATION_CODE
    console.log("请求url为==>" + url)
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      data: params,
      success(data) {
        responseSuccess(Api.GET_VERIFICATION_CODE, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.GET_VERIFICATION_CODE, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取用户信息
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getUserInfo(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.userInfo)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.GET_USER_INFO
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.GET_USER_INFO, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.GET_USER_INFO, errMsg, failureCallback)
      }
    })
  }
}
// =========================================登录相关请求 end==============================================



// =========================================登录状态的首页和其详情请求 start==============================================
/**
 * 获取登录状态下的推荐酒店列表
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getHotelListLogin(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.hotelList)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.HOTEL_LIST_LOGIN
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: {
        ...params,
        pageNumber: 1,
        pageSize: 1000
      },
      success(data) {
        responseSuccess(Api.HOTEL_LIST_LOGIN, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.HOTEL_LIST_LOGIN, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取深圳的行政区列表
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getSzRegionList(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.areasList)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.SZ_REGION_LIST
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: {
        ...params,
        pageNumber: 1,
        pageSize: 1000
      },
      success(data) {
        responseSuccess(Api.SZ_REGION_LIST, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.SZ_REGION_LIST, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取登录状态下的酒店详情
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getHotelDetailLogin(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.hotelDetail)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.HOTEL_DETAIL_LOGIN
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.HOTEL_DETAIL_LOGIN, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.HOTEL_DETAIL_LOGIN, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 收藏酒店
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function collectingHotel(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.COLLECT_HOTEL
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.COLLECT_HOTEL, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.COLLECT_HOTEL, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 取消酒店收藏
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function cancelCollectedHotel(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.CANCEL_COLLECT_HODEL
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.CANCEL_COLLECT_HODEL, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.CANCEL_COLLECT_HODEL, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 微信支付预付款
 * @param {微信临时票据} code 
 * @param {获取订单的参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function payBookingMoney(code, params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.WX_OPEN_ID
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken(),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: {
        jsCode: code,
      },
      success(res) {
        if (res.data.status === 0) {
          getOrdreAndPay({
            ...params,
            openId: res.data.data.openId
          }, successCallback, failureCallback)
        } else {
          responseSuccess(Api.WX_OPEN_ID, res, successCallback, failureCallback)
        }
      },
      fail(errMsg) {
        responseFailure(Api.WX_OPEN_ID, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取订单信息并拉起微信支付
 */
function getOrdreAndPay(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.GET_BOOKING_ORDER
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      data: params,
      header: {
        authorization: Api.getAccessToken(),
      },
      success(res) {
        if (res.data.status === 0) {
          wx.requestPayment({
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.packageInfo,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function (payRes) {
              successCallback(payRes)
            },
            'fail': function (payErr) {
              console.log("支付失败的回调：" + JSON.stringify(payErr))
              failureCallback({
                errorCode: -2,
                errorMsg: '微信支付失败'
              })
            },
          })
        } else {
          responseSuccess(Api.GET_BOOKING_ORDER, res, successCallback, failureCallback)
        }
      },
      fail(errMsg) {
        responseFailure(Api.GET_BOOKING_ORDER, errMsg, failureCallback)
      }
    })
  }
}
// =========================================登录状态的首页和其详情请求 end==============================================



// =========================================我的页面相关相关 start==============================================
/**
 * 获取我的订单列表
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getMyOrderList(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.myOrderList)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.ORDER_LIST
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: {
        ...params,
        pageNumber: 1,
        pageSize: 1000
      },
      success(data) {
        responseSuccess(Api.ORDER_LIST, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.ORDER_LIST, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取我的收藏列表
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getMyCollectionList(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.hotelList)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.COLLECT_HOTEL_LIST
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: {
        ...params,
        pageNumber: 1,
        pageSize: 1000
      },
      success(data) {
        responseSuccess(Api.COLLECT_HOTEL_LIST, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.COLLECT_HOTEL_LIST, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 获取联系人列表
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function getContactList(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback(DemoDataFactory.contactList)
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.CONTACT_LIST
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.CONTACT_LIST, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.CONTACT_LIST, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 添加联系人
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function addContact(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.ADD_CONTACT
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.ADD_CONTACT, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.ADD_CONTACT, errMsg, failureCallback)
      }
    })
  }
}

/**
 * 删除联系人
 * @param {请求参数} params 
 * @param {请求成功的回调} successCallback 
 * @param {请求失败的回调} failureCallback 
 */
export function deleteContact(params, successCallback, failureCallback) {
  if (DemoDataFactory.userDemoData) {
    setTimeout(() => {
      successCallback('')
    }, LOADING_TIME)
  } else {
    var url = Api.getBaseUrl() + Api.DELETE_CONTACT
    console.log("请求url为==>" + url)
    console.log("头部的accessToken为==>" + Api.getAccessToken())
    console.log("参数为==>" + JSON.stringify(params))
    wx.request({
      method: Api.POST,
      url: url,
      header: {
        authorization: Api.getAccessToken()
      },
      data: params,
      success(data) {
        responseSuccess(Api.DELETE_CONTACT, data, successCallback, failureCallback)
      },
      fail(errMsg) {
        responseFailure(Api.DELETE_CONTACT, errMsg, failureCallback)
      }
    })
  }
}
// =========================================我的页面相关相关 end==============================================