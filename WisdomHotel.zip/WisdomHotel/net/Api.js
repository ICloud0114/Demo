//开发环境
const DEVELOP_ENV = 'https://inner-dev.topband-cloud.com:743/hotel-app'
//测试环境
const TEST_ENV = 'https://inner.topband-cloud.com:743/smart-hotel-app'
//生产环境(正式环境)
const PRODUCT_ENV = 'https://applet.51haizhu.com/xinghuo-hotel-applet'

var baseUrl = null

export const ENV_TYPE_KEY = 'ENVIRONMENT_TYPE_KEY'
export const ACCESS_TOKEN_KEY = 'ACCESS_TOKEN_KEY'
export const REFRESH_TOKEN_KEY = 'REFRESH_TOKEN_KEY'

var accessToken = null
var refreshToken = null

export const DEFAULT_ENV_TYPE = 3 //默认为生产环境

//请求方法类型
export const GET = 'GET'
export const POST = 'POST'

//========================================各Api========================================
export const REFRESH_TOKEN = '/userlogin/refreshToken' //刷新token
//登录相关api
export const GET_VERIFICATION_CODE = '/userlogin/code' //获取手机验证码
export const PHONE_LOGIN = '/userlogin/phone/login' //手机登录
// export const WX_AUTH_LOGIN = '/userlogin/wx/login' //微信授权登录
export const WX_AUTH_PHONE_LOGIN = '/userlogin/wxAuthPhone/login' //微信授权手机号登录
export const GET_USER_INFO = '/my/login/userInfo' //获取用户信息
//酒店首页相关api
export const HOTEL_LIST_UNLOGIN = '/nonvip/hotel/list' //非登录下的酒店列表
export const HOTEL_DETAIL_UNLOGIN = '/nonvip/hotel/detail' //非登录下的酒店详情
export const HOTEL_LIST_LOGIN = '/vip/hotel/list' //登录下的酒店列表
export const HOTEL_DETAIL_LOGIN = '/vip/hotel/detail' //登录下的酒店详情
export const SZ_REGION_LIST = '/vip/hotel/addressList' //深圳行政区列表
//我的相关api
export const ORDER_LIST = '/my/order/list' //订单列表
export const CONTACT_LIST = '/my/linkman/list' //联系人列表
export const ADD_CONTACT = '/my/linkman/add' //新增联系人
export const DELETE_CONTACT = '/my/linkman/delete' //删除联系人
export const COLLECT_HOTEL_LIST = '/my/hotel/list' //收藏酒店列表
export const COLLECT_HOTEL = '/my/hotel/collect' //收藏酒店
export const CANCEL_COLLECT_HODEL = '/my/hotel/cancel' //取消收藏酒店

export const WX_OPEN_ID = '/order/auth/code2Session' //获取微信的openid
export const GET_BOOKING_ORDER = '/order/unifiedorder' //获取支付订单

/**
 * 基础域名的获取和设置
 */
export const getBaseUrl = () => {
  if (baseUrl == null) {
    var envType = DEFAULT_ENV_TYPE
    try {
      envType = Number.parseInt(wx.getStorageSync(ENV_TYPE_KEY))
      if (isNaN(envType)) {
        envType = DEFAULT_ENV_TYPE
      }
    } catch (e) {
      envType = DEFAULT_ENV_TYPE
      console.log('获取环境类型失败！')
    }
    switch (envType) {
      case 1:
        baseUrl = DEVELOP_ENV;
        break;
      case 2:
        baseUrl = TEST_ENV;
        break;
      default:
        baseUrl = PRODUCT_ENV;
        break;
    }
  }
  return baseUrl
}
export const setBaseUrl = (envType) => {
  switch (envType) {
    case 1:
      baseUrl = DEVELOP_ENV;
      break;
    case 2:
      baseUrl = TEST_ENV;
      break;
    default:
      baseUrl = PRODUCT_ENV;
      break;
  }
  try {
    wx.setStorageSync(ENV_TYPE_KEY, envType)
  } catch (e) {
    console.log('保存环境类型失败!')
  }
}
/**
 * 处理accessToken
 */
export const getAccessToken = () => {
  if (accessToken != null) {
    return accessToken
  } else {
    try {
      return wx.getStorageSync(ACCESS_TOKEN_KEY)
    } catch (err) {
      console.log('从文件中获取accessToken失败！')
      return ''
    }
  }
}
export const setAccessToken = (token) => {
  accessToken = token
  try {
    wx.setStorageSync(ACCESS_TOKEN_KEY, token)
  } catch (e) {
    console.log('保存环境类型失败!')
  }
}
/**
 * 处理refreshToken
 */
export const getRefreshToken = () => {
  if (refreshToken != null) {
    return refreshToken
  } else {
    try {
      return wx.getStorageSync(REFRESH_TOKEN_KEY)
    } catch (err) {
      console.log('从文件中获取refreshToken失败！')
      return ''
    }
  }
}
export const setRefreshToken = (token) => {
  refreshToken = token
  try {
    wx.setStorageSync(REFRESH_TOKEN_KEY, token)
  } catch (e) {
    console.log('保存环境类型失败!')
  }
}