// pages/homepage/searchHotel/searchHotel.js
const app = getApp()
const util = require("../../../utils/dateUtils")
const Request = require("../../../net/Request")

var loading = {}
var toast = {}

var searchParams = {}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    selectedAre: '',
    areas: [],
    hotels: [],

    checkInStartDate: util.formatTime(new Date()), //入住picker的开始日期（yyyy-MM-dd）
    leaveStartDate: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店picker的开始时间（yyyy-MM-dd）
    checkInTime: util.formatTime(new Date()), //入住时间（yyyy-MM-dd）
    checkInFormatTime: util.formatShowTime(new Date()), //入住时间（MM月dd日）
    checkInWeek: util.formatWeek(new Date()), //入住星期数（周一，周二。。。）
    leaveTime: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（yyyy-MM-dd）
    leaveFormatTime: util.formatShowTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（（MM月dd日）
    leaveWeek: util.formatWeek(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店星期数（周一，周二。。。）
    liveDays: 1,

    choosearea: false, //是否显示选择地区
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(JSON.stringify(options))
    //初始化数据
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
    searchParams = {
      prefecture: options.area,
      startTime: options.checkInTime + ' 12:00:00',
      endTime: options.leaveTime + ' 12:00:00'
    }
    let checkInDate = new Date(options.checkInTime);
    let leaveDate = new Date(options.leaveTime);
    //刷新页面
    this.setData({
      areas: app.appData.szRegionList,
      selectedAre: options.area == null || options.area.length <= 0 ? this.data.selectedAre : options.area,
      leaveStartDate: util.formatTime(new Date(checkInDate.getTime() + 24 * 60 * 60 * 1000)),
      checkInTime: options.checkInTime,
      checkInFormatTime: util.formatShowTime(checkInDate),
      checkInWeek: util.formatWeek(checkInDate),
      leaveTime: options.leaveTime,
      leaveFormatTime: util.formatShowTime(leaveDate),
      leaveWeek: util.formatWeek(leaveDate),
      liveDays: options.liveDays
    })
  },
  onReady: function () {
    this.loadSearchHotelList()
  },
  //选择地区相关
  noScrollEvent(e) {}, //阻止滑动事件冒泡
  dismissAreaPop(e) {
    this.setData({
      choosearea: false
    })
  },
  seletarea() {
    this.setData({
      choosearea: true
    })
  },
  areatap(res) {
    var index = res.currentTarget.dataset.index;
    this.data.selectedAre = this.data.areas[index].name
    this.setData({
      selectedAre: this.data.selectedAre,
      choosearea: false
    })
    //重新加载搜索到列表
    searchParams = {
      ...searchParams,
      prefecture: this.data.selectedAre
    }
    this.loadSearchHotelList()
  },
  //选择入住时间
  changeCheckInTime(res) {
    var selectedCheckInDate = new Date(res.detail.value);
    var newLeaveStartDate = new Date(selectedCheckInDate.getTime() + 24 * 60 * 60 * 1000);
    if ((new Date(this.data.leaveTime)).getTime() - newLeaveStartDate.getTime() < 0) {
      this.data.checkInTime = util.formatTime(selectedCheckInDate)
      this.data.leaveTime = util.formatTime(newLeaveStartDate)
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: this.data.checkInTime,
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        leaveTime: this.data.leaveTime,
        leaveFormatTime: util.formatShowTime(newLeaveStartDate),
        leaveWeek: util.formatWeek(newLeaveStartDate),
        liveDays: 1
      })
    } else {
      var newLiveDays = ((new Date(this.data.leaveTime)).getTime() - selectedCheckInDate.getTime()) / (24 * 60 * 60 * 1000)
      this.data.checkInTime = util.formatTime(selectedCheckInDate)
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: this.data.checkInTime,
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        liveDays: newLiveDays
      })
    }
    //重新加载搜索到列表
    searchParams = {
      ...searchParams,
      startTime: this.data.checkInTime + ' 12:00:00',
      endTime: this.data.leaveTime + ' 12:00:00'
    }
    this.loadSearchHotelList()
  },
  //选择离店时间
  changeLeaveTime(res) {
    var selectedLeaveDate = new Date(res.detail.value);
    var newLiveDays = (selectedLeaveDate.getTime() - (new Date(this.data.checkInTime)).getTime()) / (24 * 60 * 60 * 1000)
    this.data.leaveTime = util.formatTime(selectedLeaveDate)
    this.setData({
      leaveTime: this.data.leaveTime,
      leaveFormatTime: util.formatShowTime(selectedLeaveDate),
      leaveWeek: util.formatWeek(selectedLeaveDate),
      liveDays: newLiveDays
    })
    //重新加载搜索到列表
    searchParams = {
      ...searchParams,
      endTime: this.data.leaveTime + ' 12:00:00'
    }
    this.loadSearchHotelList()
  },
  select(res) {
    var that = this
    let index = res.currentTarget.dataset.index
    let hotelNo = this.data.hotels[index].hotelNo
    wx.navigateTo({
      url: '../hotelDetail/hotelDetail?hotelNo=' + hotelNo + '&checkInTime=' + that.data.checkInTime + '&leaveTime=' + that.data.leaveTime + '&liveDays=' + that.data.liveDays,
    })
  },
  //载入搜索到的酒店列表
  loadSearchHotelList() {
    var that = this
    loading.showLoading()
    Request.getHotelListLogin(searchParams, (hotelList) => {
      loading.dismissLoading()
      //刷新页面
      that.setData({
        hotels: hotelList.rows
      })
    }, (errMsg) => {
      loading.dismissLoading()
      toast.show(errMsg.errorMsg)
    })
  }
})