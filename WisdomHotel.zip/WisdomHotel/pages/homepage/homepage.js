// pages/homepage/homepage.js
const app = getApp()
const util = require("../../utils/dateUtils")
const globalData = require("../../utils/fixedGolbalData")
const Api = require("../../net/Api")
const Request = require("../../net/Request")

var loading = {}
var toast = {}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    needRefreshIcon: !app.isHightVersion("2.10.1"),
    refreshFinished: true,
    isLogin: app.appData.userInfo != null,
    hasGotUserInfo: false,
    nickName: app.getNickName(),
    avatarUrl: app.getAvatarUrl(),

    unloginScrollHeight: app.appData.windowHeight - 210,
    hotelContentMinHeight: app.appData.windowHeight - 210 - 280 - 20 + 3,

    hotels: [],
    selectedAre: '',
    areas: [],

    checkInStartDate: util.formatTime(new Date()), //入住picker的开始日期（yyyy-MM-dd）
    leaveStartDate: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店picker的开始时间（yyyy-MM-dd）
    checkInTime: util.formatTime(new Date()), //入住时间（yyyy-MM-dd）
    checkInFormatTime: util.formatShowTime(new Date()), //入住时间（MM月dd日）
    checkInWeek: util.formatWeek(new Date()), //入住星期数（周一，周二。。。）
    leaveTime: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（yyyy-MM-dd）
    leaveFormatTime: util.formatShowTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（（MM月dd日）
    leaveWeek: util.formatWeek(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店星期数（周一，周二。。。）
    liveDays: 1,

    choosearea: false, //是否显示选择地区

    lastClickTime: 0,
    clickTimes: 0,
    showEnvPop: false,
    currentEnvType: Api.DEFAULT_ENV_TYPE,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
  },
  //生命周期回调—监听页面初次渲染完成
  onReady: function () {
    var that = this
    loading.showLoading()
    Request.getUserInfo({}, (userInfo) => {
      app.appData.userInfo = userInfo
      that.data.isLogin = app.appData.userInfo != null
      that.data.hasGotUserInfo = true
      //加载页面
      that.setData({
        isLogin: that.data.isLogin,
        hasGotUserInfo: that.data.hasGotUserInfo,
      })
      //加载登录后推荐酒店列表
      that.loadHotelList()
    }, (errMsg) => {
      that.data.hasGotUserInfo = true
      //加载页面
      that.setData({
        isLogin: that.data.isLogin,
        hasGotUserInfo: that.data.hasGotUserInfo,
      })
      //加载未登录的推荐酒店列表
      that.loadHotelList()
    })
  },
  //生命周期回调—监听页面显示
  onShow: function () {
    //加载深圳行政区列表
    this.loadSzRegionList()
    if (!this.data.isLogin && app.appData.userInfo != null) {
      this.refreshLogin()
    }
  },
  pullRefresh() {
    this.loadHotelList()
  },
  clickRefreshIcon() {
    loading.showLoading()
    this.loadHotelList()
  },
  changeEnv(res) {
    let currentTime = res.timeStamp;
    if (this.data.lastClickTime === 0 || currentTime - this.data.lastClickTime < 2 * 1000) {
      this.data.clickTimes += 1
      this.data.lastClickTime = currentTime
    } else {
      this.data.lastClickTime = 0
      this.data.clickTimes = 0
    }
    if (this.data.clickTimes >= 7) {
      try {
        this.data.currentEnvType = Number.parseInt(wx.getStorageSync(Api.ENV_TYPE_KEY))
        if (isNaN(this.data.currentEnvType)) {
          this.data.currentEnvType = Api.DEFAULT_ENV_TYPE
        }
      } catch (err) {
        this.data.currentEnvType = Api.DEFAULT_ENV_TYPE
        console.log("获取环境类型出错!")
      }
      this.setData({
        showEnvPop: true,
        currentEnvType: this.data.currentEnvType
      })
      this.data.lastClickTime = 0
      this.data.clickTimes = 0
    }
  },
  itemtap(res) {
    let hotelNo = this.data.hotels[res.currentTarget.dataset.index].hotelNo
    wx.navigateTo({
      url: 'hotelDetail/hotelDetail?hotelNo=' + hotelNo,
    })
  },
  //进去查询酒店界面
  queryhotel() {
    var that = this;
    wx.navigateTo({
      url: 'searchHotel/searchHotel?area=' + that.data.selectedAre + '&checkInTime=' + that.data.checkInTime + '&leaveTime=' + that.data.leaveTime + '&liveDays=' + that.data.liveDays,
    })
  },
  //选择入住时间
  changeCheckInTime(e) {
    var selectedCheckInDate = new Date(e.detail.value);
    var newLeaveStartDate = new Date(selectedCheckInDate.getTime() + 24 * 60 * 60 * 1000);
    if ((new Date(this.data.leaveTime)).getTime() - newLeaveStartDate.getTime() < 0) {
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: util.formatTime(selectedCheckInDate),
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        leaveTime: util.formatTime(newLeaveStartDate),
        leaveFormatTime: util.formatShowTime(newLeaveStartDate),
        leaveWeek: util.formatWeek(newLeaveStartDate),
        liveDays: 1
      })
    } else {
      var newLiveDays = ((new Date(this.data.leaveTime)).getTime() - selectedCheckInDate.getTime()) / (24 * 60 * 60 * 1000)
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: util.formatTime(selectedCheckInDate),
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        liveDays: newLiveDays
      })
    }
  },
  //选择离店时间
  changeLeaveTime(e) {
    var selectedLeaveDate = new Date(e.detail.value);
    var newLiveDays = (selectedLeaveDate.getTime() - (new Date(this.data.checkInTime)).getTime()) / (24 * 60 * 60 * 1000)
    this.setData({
      leaveTime: util.formatTime(selectedLeaveDate),
      leaveFormatTime: util.formatShowTime(selectedLeaveDate),
      leaveWeek: util.formatWeek(selectedLeaveDate),
      liveDays: newLiveDays
    })
  },
  //选择地区相关
  noScrollEvent(e) {}, //阻止滑动事件冒泡
  dismissAreaPop(e) {
    this.setData({
      choosearea: false
    })
  },
  seletarea() {
    if (this.data.areas.length <= 0) {
      this.data.areas = app.appData.szRegionList
    }
    this.setData({
      choosearea: true,
      areas: this.data.areas
    })
  },
  areatap(e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      selectedAre: this.data.areas[index].name,
      choosearea: false
    })
  },
  //载入深圳行政区列表
  loadSzRegionList() {
    if (app.appData.szRegionList != null) {
      this.data.areas = app.appData.szRegionList
      return
    }
    var that = this
    Request.getSzRegionList({
      parentId: 440300
    }, (regionList) => {
      app.appData.szRegionList = regionList
      that.data.areas = regionList
    }, () => {
      app.appData.szRegionList = globalData.szRegionList
      that.data.areas = app.appData.szRegionList
    })
  },
  //载入推荐酒店列表
  loadHotelList() {
    var that = this
    if (this.data.isLogin) {
      Request.getHotelListLogin({}, (hotelList) => {
        that.setData({
          isLogin: that.data.isLogin,
          nickName: app.getNickName(),
          avatarUrl: app.getAvatarUrl(),
          hotels: hotelList.rows,
          refreshFinished: false
        })
        loading.dismissLoading()
      }, (errMsg) => {
        that.setData({
          refreshFinished: false
        })
        loading.dismissLoading()
        toast.show(errMsg.errorMsg)
      })
    } else {
      Request.getHotelListUnlogin((hotelList) => {
          that.setData({
            hotels: hotelList.rows,
            refreshFinished: false
          })
          loading.dismissLoading()
        },
        (errMsg) => {
          that.setData({
            refreshFinished: false
          })
          loading.dismissLoading()
          toast.show(errMsg.errorMsg)
        })
    }
  },
  //从未登录到登录执行此方法刷新页面
  refreshLogin() {
    console.log("homePage--用户登录了-->需重新加载数据！")
    this.data.isLogin = app.appData.userInfo != null
    //加载推荐酒店列表
    loading.showLoading()
    this.loadHotelList()
  },
  //切换环境
  selectedEnv(res) {
    // let envType = Number.parseInt(res.target.dataset.type)
    // Api.setBaseUrl(envType)
    // this.data.showEnvPop = false
    // this.setData({
    //   showEnvPop: this.data.showEnvPop,
    // })
    // console.log('切换后的环境为：' + Api.getBaseUrl())
    // //重新加载数据,刷新页面
    // loading.showLoading()
    // this.loadHotelList()
  },
})