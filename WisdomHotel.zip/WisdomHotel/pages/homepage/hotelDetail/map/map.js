// pages/homepage/hotelDetail/map/map.js
const app = getApp();

Page({
  /**
   * 页面的初始数据
   */
  data: {
    renderMap: false,
    hotelAddress: '',
    longitude: 114.057886,
    latitude: 22.543110,
    markers: [],
    scale: 12,
    controls: [{
      id: 0,
      iconPath: "../../../../images/findHotel.png",
      position: {
        left: app.appData.screenWidth - 66,
        top: 32,
        width: 32,
        height: 32
      },
      clickable: true
    }]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(JSON.stringify(options))
    this.setData({
      renderMap: true,
      hotelAddress: options.addressName,
      longitude: options.longitude,
      latitude: options.latitude,
      scale: 16,
      markers: [{
        iconPath: "../../../../images/hotelAddr.png",
        id: 0,
        longitude: options.longitude,
        latitude: options.latitude,
        label: {
          content: options.addressName, //文本
          color: '#FF0202', //文本颜色
          borderRadius: 3, //边框圆角
          borderWidth: 1, //边框宽度
          borderColor: '#FF0202', //边框颜色
          bgColor: '#ffffff', //背景色
          padding: 5, //文本边缘留白
          textAlign: 'center' //文本对齐方式。有效值: left, right, center
        },
        width: 30,
        height: 38
      }]
    })
  },
  controlClick(e) {
    this.setData({
      longitude: this.data.longitude,
      latitude: this.data.latitude,
      scale: 18
    })
  },
})