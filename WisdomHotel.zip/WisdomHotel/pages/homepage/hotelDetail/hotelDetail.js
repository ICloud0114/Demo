const app = getApp()
const util = require("../../../utils/dateUtils")
const Request = require("../../../net/Request")

var hotelNo = ''
var unloginPop = {}
var loading = {}
var toast = {}
var isLogin = false

Page({
  /**
   * 页面的初始数据
   */
  data: {
    hotelDetail: {},
    isfavorite: false,

    checkInStartDate: util.formatTime(new Date()), //入住picker的开始日期（yyyy-MM-dd）
    leaveStartDate: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店picker的开始时间（yyyy-MM-dd）
    checkInTime: util.formatTime(new Date()), //入住时间（yyyy-MM-dd）
    checkInFormatTime: util.formatShowTime(new Date()), //入住时间（MM月dd日）
    checkInWeek: util.formatWeek(new Date()), //入住星期数（周一，周二。。。）
    leaveTime: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（yyyy-MM-dd）
    leaveFormatTime: util.formatShowTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（（MM月dd日）
    leaveWeek: util.formatWeek(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店星期数（周一，周二。。。）
    liveDays: 1,

    choosearea: false,
    roomNum: 1, //房间数
    selectedRoomNum: 1, //已选中的房间数
    personNum: 1, //客人数
    selectedPersonNum: 1, //选中的客人数
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    unloginPop = this.selectComponent('#unloginPop')
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
    isLogin = app.appData.userInfo != null
    console.log("带进来的参数为：" + JSON.stringify(options))
    //根据是否有传入入住时间信息，决定是否刷新页面
    hotelNo = options.hotelNo
    let selectedCheckInTime = options.checkInTime //YYYY-MM-dd
    var selectedLeaveTime = options.leaveTime
    let hasCheckInTime = selectedCheckInTime != undefined && selectedCheckInTime != null && selectedCheckInTime !== "undefined" && selectedCheckInTime !== "null"
    if (hasCheckInTime) {
      let checkInDate = new Date(selectedCheckInTime);
      let hasLeaveTime = selectedLeaveTime != undefined && selectedLeaveTime != null && selectedLeaveTime !== "undefined" && selectedLeaveTime !== "null"
      let leaveDate = hasLeaveTime ? new Date(selectedLeaveTime) : new Date(checkInDate.getTime() + 24 * 60 * 60 * 1000);
      this.setData({
        leaveStartDate: util.formatTime(new Date(checkInDate.getTime() + 24 * 60 * 60 * 1000)),
        checkInTime: options.checkInTime,
        checkInFormatTime: util.formatShowTime(checkInDate),
        checkInWeek: util.formatWeek(checkInDate),
        leaveTime: options.leaveTime,
        leaveFormatTime: util.formatShowTime(leaveDate),
        leaveWeek: util.formatWeek(leaveDate),
        liveDays: options.liveDays
      })
    }
  },
  onReady: function () {
    this.loadHotelDetailInfo()
  },
  //收藏点击事件
  setCollection() {
    var that = this;
    //已登录
    if (isLogin) {
      loading.showLoading()
      if (this.data.hotelDetail.collect === 1) {
        Request.cancelCollectedHotel({
          hotelNo: this.data.hotelDetail.hotelNo
        }, () => {
          loading.dismissLoading()
          that.setData({
            hotelDetail: {
              ...that.data.hotelDetail,
              collect: 0
            },
            isfavorite: false
          })
        }, (errMsg) => {
          loading.dismissLoading()
          toast.show(errMsg.errorMsg)
        })
      } else {
        Request.collectingHotel({
          hotelNo: this.data.hotelDetail.hotelNo
        }, () => {
          loading.dismissLoading()
          that.setData({
            hotelDetail: {
              ...that.data.hotelDetail,
              collect: 1
            },
            isfavorite: true
          })
        }, (errMsg) => {
          loading.dismissLoading()
          toast.show(errMsg.errorMsg)
        })
      }
      //未登录
    } else {
      this.showLoginRemindPop()
    }
  },
  //跳转到腾讯地图导航
  mapNavigation() {
    var that = this;
    wx.navigateTo({
      url: 'map/map?addressName=' + that.data.hotelDetail.detailedAddress + '&longitude=' + that.data.hotelDetail.longitude + '&latitude=' + that.data.hotelDetail.latitude,
    })
  },
  //选择入住时间
  changeCheckInTime(e) {
    var selectedCheckInDate = new Date(e.detail.value);
    var newLeaveStartDate = new Date(selectedCheckInDate.getTime() + 24 * 60 * 60 * 1000);
    if ((new Date(this.data.leaveTime)).getTime() - newLeaveStartDate.getTime() < 0) {
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: util.formatTime(selectedCheckInDate),
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        leaveTime: util.formatTime(newLeaveStartDate),
        leaveFormatTime: util.formatShowTime(newLeaveStartDate),
        leaveWeek: util.formatWeek(newLeaveStartDate),
        liveDays: 1
      })
    } else {
      var newLiveDays = ((new Date(this.data.leaveTime)).getTime() - selectedCheckInDate.getTime()) / (24 * 60 * 60 * 1000)
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: util.formatTime(selectedCheckInDate),
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        liveDays: newLiveDays
      })
    }
  },
  //选择离店时间
  changeLeaveTime(e) {
    var selectedLeaveDate = new Date(e.detail.value);
    var newLiveDays = (selectedLeaveDate.getTime() - (new Date(this.data.checkInTime)).getTime()) / (24 * 60 * 60 * 1000)
    this.setData({
      leaveTime: util.formatTime(selectedLeaveDate),
      leaveFormatTime: util.formatShowTime(selectedLeaveDate),
      leaveWeek: util.formatWeek(selectedLeaveDate),
      liveDays: newLiveDays
    })
  },
  //预定点击事件
  reserve(res) {
    //已登录
    if (isLogin) {
      let selectedInfo = {
        checkInTime: this.data.checkInTime,
        leaveTime: this.data.leaveTime,
        liveDays: this.data.liveDays,
        selectedRoomNum: this.data.selectedRoomNum,
        selectedPersonNum: this.data.selectedPersonNum
      }
      let index = res.currentTarget.dataset.index
      let room = this.data.hotelDetail.roomList[index]
      room = {
        ...room,
        hotelNo: this.data.hotelDetail.hotelNo,
        hotelName: this.data.hotelDetail.hotelName
      }
      wx.navigateTo({
        url: 'reserve/reserve?selectedInfo=' + JSON.stringify(selectedInfo) + "&hotelRoomInfo=" + JSON.stringify(room),
      })
      //未登录
    } else {
      this.showLoginRemindPop()
    }
  },
  showLoginRemindPop() {
    unloginPop.showPop({
      needTitle: false,
      content: '您还未登录，请登录后再操作',
      cancelText: '取消',
      sureText: '登录'
    }, (res) => {
      wx.navigateTo({
        url: '../../login/login',
      })
    })
  },
  //选择人数房间数
  noScrollMove() {}, //阻止滑动事件冒泡
  selectRoomPerson() {
    this.setData({
      choosearea: true
    })
  },
  sure() {
    this.setData({
      selectedRoomNum: this.data.roomNum,
      selectedPersonNum: this.data.personNum,
      choosearea: false
    })
  },
  cancel() {
    this.dismissPop()
  },
  dismissPop() {
    this.setData({
      roomNum: this.data.selectedRoomNum,
      personNum: this.data.selectedPersonNum,
      choosearea: false
    })
  },
  roomNumplus() {
    var roomNum = this.data.roomNum + 1;
    this.setData({
      roomNum: roomNum,
    })
  },
  roomNumberminus() {
    if (this.data.roomNum > 1) {
      var roomNum = this.data.roomNum - 1;
      this.setData({
        roomNum: roomNum,
      })
    }
  },
  numberplus() {
    var number = this.data.personNum + 1;
    this.setData({
      personNum: number,
    })
  },
  numberminus() {
    if (this.data.personNum > 1) {
      var number = this.data.personNum - 1;
      this.setData({
        personNum: number,
      })
    }
  },
  //载入酒店详情数据
  loadHotelDetailInfo() {
    var that = this;
    loading.showLoading()
    if (isLogin) {
      Request.getHotelDetailLogin({
        hotelNo: hotelNo
      }, (hotelDetailUnlogin) => {
        that.dealHotelDetailInfo(hotelDetailUnlogin)
        loading.dismissLoading()
      }, (errMsg) => {
        loading.dismissLoading()
        toast.show(errMsg.errorMsg)
      })
    } else {
      Request.getHotelDetailUnlogin({
        hotelNo: hotelNo
      }, (hotelDetailLogin) => {
        that.dealHotelDetailInfo(hotelDetailLogin)
        loading.dismissLoading()
      }, (errMsg) => {
        loading.dismissLoading()
        toast.show(errMsg.errorMsg)
      })
    }
  },
  dealHotelDetailInfo(hotelDetail) {
    //处理酒店图片
    hotelDetail = {
      ...hotelDetail,
      hotelImgs: hotelDetail.imgUrls != null ? hotelDetail.imgUrls.split(',') : []
    }
    //处理房间图片
    hotelDetail.roomList.forEach((item, index) => {
      hotelDetail.roomList[index] = {
        ...item,
        roomImg: item.imgUrls != null ? item.imgUrls.split(",")[0] : ''
      }
    });
    this.setData({
      hotelDetail: hotelDetail,
      isfavorite: hotelDetail.collect === 1
    })
  },
  //从未登录到登录执行此方法刷新页面
  refreshLogin() {
    console.log("hotelDetail--用户登录了-->需重新加载数据！")
    isLogin = app.appData.userInfo != null
    //加载登录后的酒店详情
    this.loadHotelDetailInfo()
  }
})