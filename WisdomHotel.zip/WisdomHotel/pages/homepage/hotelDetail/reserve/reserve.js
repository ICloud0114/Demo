// pages/homepage/hotelDetail/reserve/reserve.js
const app = getApp()
const util = require("../../../../utils/dateUtils")
const verifyUtils = require("../../../../utils/verifyUtls")
const Request = require('../../../../net/Request')

var paySuccessPop = {}
var loading = {}
var toast = {}

var orderParams = {}
var hasPayedSuccessfully = false

var originalPrice = 0
var vipPrice = 0

Page({
  /**
   * 页面的初始数据
   */
  data: {
    scrollContainerHeight: app.appData.screenHeight - app.appData.actionBarHeight - 121,
    hotelRoomInfo: {},

    checkInStartDate: util.formatTime(new Date()), //入住picker的开始日期（yyyy-MM-dd）
    leaveStartDate: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店picker的开始时间（yyyy-MM-dd）
    checkInTime: util.formatTime(new Date()), //入住时间（yyyy-MM-dd）
    checkInFormatTime: util.formatShowTime(new Date()), //入住时间（MM月dd日）
    checkInWeek: util.formatWeek(new Date()), //入住星期数（周一，周二。。。）
    leaveTime: util.formatTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（yyyy-MM-dd）
    leaveFormatTime: util.formatShowTime(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店时间（（MM月dd日）
    leaveWeek: util.formatWeek(new Date((new Date()).getTime() + 24 * 60 * 60 * 1000)), //离店星期数（周一，周二。。。）
    liveDays: 1,

    choosearea: false,
    roomNum: 1, //房间数
    selectedRoomNum: 1, //已选中的房间数
    personNum: 1, //客人数
    selectedPersonNum: 1, //选中的客人数

    earliestArriveTime: "",
    selectedArriveTime: "",

    name: '',
    phone: '',

    payMoney: "0",
    savedMoney: "0"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let selectedInfo = JSON.parse(options.selectedInfo)
    let checkInDate = new Date(selectedInfo.checkInTime);
    let todayDate = new Date(util.formatTime(new Date()))
    let leaveDate = new Date(selectedInfo.leaveTime);
    this.data.hotelRoomInfo = JSON.parse(options.hotelRoomInfo)
    originalPrice = Number.parseFloat(this.data.hotelRoomInfo.originalPrice)
    vipPrice = Number.parseFloat(this.data.hotelRoomInfo.vipPrice)
    this.setData({
      hotelRoomInfo: this.data.hotelRoomInfo,
      leaveStartDate: util.formatTime(new Date(checkInDate.getTime() + 24 * 60 * 60 * 1000)),
      checkInTime: selectedInfo.checkInTime,
      checkInFormatTime: util.formatShowTime(checkInDate),
      checkInWeek: util.formatWeek(checkInDate),
      leaveTime: selectedInfo.leaveTime,
      leaveFormatTime: util.formatShowTime(leaveDate),
      leaveWeek: util.formatWeek(leaveDate),
      liveDays: selectedInfo.liveDays,

      roomNum: Number.parseInt(selectedInfo.selectedRoomNum),
      selectedRoomNum: Number.parseInt(selectedInfo.selectedRoomNum),
      personNum: Number.parseInt(selectedInfo.selectedPersonNum),
      selectedPersonNum: Number.parseInt(selectedInfo.selectedPersonNum),

      earliestArriveTime: checkInDate.getTime() > todayDate.getTime() ? '00:00' : util.currentFormatTime(),
      selectedArriveTime: checkInDate.getTime() > todayDate.getTime() ? '11:00' : util.currentFormatTime(),

      phone: app.appData.userInfo.mob,

      payMoney: Number.parseFloat(vipPrice * Number.parseInt(selectedInfo.selectedRoomNum) * Number.parseInt(selectedInfo.liveDays)).toFixed(2),
      savedMoney: Number.parseFloat((originalPrice - vipPrice) * Number.parseInt(selectedInfo.selectedRoomNum) * Number.parseInt(selectedInfo.liveDays)).toFixed(2),
    })
    //初始化弹窗,loading,toast相关
    paySuccessPop = this.selectComponent('#paySuccessPop')
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
  },
  onUnload: function () {
    if (hasPayedSuccessfully) {
      //回退至首页(！！！onUnload方法执行的时候，该页面实际上已经退出栈了，即该页的前一页才是当前页，所以url的值尤其注意)
      wx.switchTab({
        url: '../homepage',
      })
    }
  },
  //选择入住时间
  changeCheckInTime(e) {
    var selectedCheckInDate = new Date(e.detail.value);
    let todayDate = new Date(util.formatTime(new Date()))
    var newLeaveStartDate = new Date(selectedCheckInDate.getTime() + 24 * 60 * 60 * 1000);
    if ((new Date(this.data.leaveTime)).getTime() - newLeaveStartDate.getTime() < 0) {
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: util.formatTime(selectedCheckInDate),
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        leaveTime: util.formatTime(newLeaveStartDate),
        leaveFormatTime: util.formatShowTime(newLeaveStartDate),
        leaveWeek: util.formatWeek(newLeaveStartDate),
        liveDays: 1,
        earliestArriveTime: selectedCheckInDate.getTime() > todayDate.getTime() ? '00:00' : util.currentFormatTime(),
        selectedArriveTime: selectedCheckInDate.getTime() > todayDate.getTime() ? '11:00' : util.currentFormatTime(),

        payMoney: Number.parseFloat(vipPrice * this.data.selectedRoomNum * 1).toFixed(2),
        savedMoney: Number.parseFloat((originalPrice - vipPrice) * this.data.selectedRoomNum * 1).toFixed(2),
      })
    } else {
      var newLiveDays = ((new Date(this.data.leaveTime)).getTime() - selectedCheckInDate.getTime()) / (24 * 60 * 60 * 1000)
      this.setData({
        leaveStartDate: util.formatTime(newLeaveStartDate),
        checkInTime: util.formatTime(selectedCheckInDate),
        checkInFormatTime: util.formatShowTime(selectedCheckInDate),
        checkInWeek: util.formatWeek(selectedCheckInDate),
        liveDays: newLiveDays,
        earliestArriveTime: selectedCheckInDate.getTime() > todayDate.getTime() ? '00:00' : util.currentFormatTime(),
        selectedArriveTime: selectedCheckInDate.getTime() > todayDate.getTime() ? '11:00' : util.currentFormatTime(),

        payMoney: Number.parseFloat(vipPrice * this.data.selectedRoomNum * newLiveDays).toFixed(2),
        savedMoney: Number.parseFloat((originalPrice - vipPrice) * this.data.selectedRoomNum * newLiveDays).toFixed(2),
      })
    }
  },
  //选择离店时间
  changeLeaveTime(e) {
    var selectedLeaveDate = new Date(e.detail.value);
    var newLiveDays = (selectedLeaveDate.getTime() - (new Date(this.data.checkInTime)).getTime()) / (24 * 60 * 60 * 1000)
    this.setData({
      leaveTime: util.formatTime(selectedLeaveDate),
      leaveFormatTime: util.formatShowTime(selectedLeaveDate),
      leaveWeek: util.formatWeek(selectedLeaveDate),
      liveDays: newLiveDays,

      payMoney: Number.parseFloat(vipPrice * this.data.selectedRoomNum * newLiveDays).toFixed(2),
      savedMoney: Number.parseFloat((originalPrice - vipPrice) * this.data.selectedRoomNum * newLiveDays).toFixed(2),
    })
  },
  //选择人数房间数
  noScrollMove() {}, //阻止滑动事件冒泡
  selectRoomPerson() {
    this.setData({
      choosearea: true
    })
  },
  sure() {
    this.setData({
      selectedRoomNum: this.data.roomNum,
      selectedPersonNum: this.data.personNum,
      payMoney: Number.parseFloat(vipPrice * this.data.roomNum * this.data.liveDays).toFixed(2),
      savedMoney: Number.parseFloat((originalPrice - vipPrice) * this.data.roomNum * this.data.liveDays).toFixed(2),
      choosearea: false
    })
  },
  cancel() {
    this.dismissPop()
  },
  dismissPop() {
    this.setData({
      roomNum: this.data.selectedRoomNum,
      personNum: this.data.selectedPersonNum,
      choosearea: false
    })
  },
  roomNumplus() {
    this.setData({
      roomNum: this.data.roomNum + 1,
    })
  },
  roomNumberminus() {
    if (this.data.roomNum > 1) {
      let number = this.data.roomNum - 1
      this.setData({
        roomNum: number,
      })
    }
  },
  numberplus() {
    this.setData({
      personNum: this.data.personNum + 1,
    })
  },
  numberminus() {
    if (this.data.personNum > 1) {
      let number = this.data.personNum - 1
      this.setData({
        personNum: number,
      })
    }
  },
  // 选择预计到店时间
  setArriveTime(res) {
    this.setData({
      selectedArriveTime: res.detail.value,
    })
  },
  // 支付预付款
  playment() {
    if (this.data.name.trim().length == 0) {
      toast.show('请输入您的姓名')
      return
    }
    if (!verifyUtils.isMobilePhone(this.data.phone)) {
      toast.show('请正确输入您的手机号')
      return
    }
    orderParams = {
      roomCategoryId: this.data.hotelRoomInfo.roomId,
      hotelId: this.data.hotelRoomInfo.hotelNo,
      bookerName: this.data.name,
      bookerPhone: this.data.phone,
      startTime: this.data.checkInTime + ' 12:00:00',
      endTime: this.data.leaveTime + ' 12:00:00',
      arrivalTime: this.data.checkInTime + " " + this.data.selectedArriveTime + ":00",
      roomNumber: this.data.selectedRoomNum,
      personNum: this.data.selectedPersonNum,
      money: this.data.hotelRoomInfo.vipPrice * this.data.selectedRoomNum * this.data.liveDays,
    }
    //微信支付预付款
    loading.showLoading()
    wx.login({
      success: (res) => {
        Request.payBookingMoney(res.code, orderParams, (res) => {
          hasPayedSuccessfully = true
          loading.dismissLoading()
          //弹出支付成功的提示弹窗
          paySuccessPop.showPop({
            needTitle: false,
            content: '预订成功!',
            isSingleBtn: true,
            sureText: '确定'
          }, () => {}, () => {}, () => {
            //回退至首页
            wx.switchTab({
              url: '../../homepage',
            })
          })
        }, (err) => {
          loading.dismissLoading()
          toast.show(err.errorMsg)
        })
      },
    })
  },
  goToContactPage() {
    wx.navigateTo({
      url: '../../../mine/commoninfo/commoninfo?fromPage=booking',
    })
  },
  setContact(contact) {
    this.setData({
      name: contact.linkman,
      phone: contact.mob
    })
  },
  inputName(res) {
    this.data.name = res.detail.value
  },
  inputPhone(res) {
    this.data.phone = res.detail.value
  }
})