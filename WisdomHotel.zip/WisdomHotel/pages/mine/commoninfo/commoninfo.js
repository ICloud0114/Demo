const app = getApp()
const Request = require("../../../net/Request")

var loading = {}
var toast = {}

var fromPage = ''

Page({
  /**
   * 页面的初始数据
   */
  data: {
    hasLoadingData: false,
    contactList: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    fromPage = options.fromPage
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
  },
  onReady: function () {
    this.getContactList(true)
  },
  //获取联系人列列表
  getContactList(needLoading) {
    var that = this
    if (needLoading) {
      loading.showLoading()
    }
    Request.getContactList({}, (contactList) => {
      loading.dismissLoading()
      that.setData({
        hasLoadingData: true,
        contactList: contactList,
      })
    }, (errMsg) => {
      that.setData({
        hasLoadingData: true,
      })
      loading.dismissLoading()
      toast.show(errMsg.errorMsg)
    })
  },
  showToast(msg) {
    toast.show(msg)
  },
  //删除联系人
  deleteContact(res) {
    var that = this
    loading.showLoading()
    Request.deleteContact({
      id: this.data.contactList[res.currentTarget.dataset.index].id
    }, () => {
      that.getContactList(false)
    }, (errMsg) => {
      loading.dismissLoading()
      toast.show(errMsg.errorMsg)
    })
  },
  //添加联系人
  addContact(res) {
    wx.navigateTo({
      url: './addcontact/addcontact',
    })
  },
  //选择联系人
  selectedContact(res) {
    if (fromPage === "booking") {
      let pages = getCurrentPages();
      let currPage = pages[pages.length - 2];
      let contact = this.data.contactList[res.currentTarget.dataset.index]
      currPage.setContact(contact)
      wx.navigateBack({})
    }
  }
})