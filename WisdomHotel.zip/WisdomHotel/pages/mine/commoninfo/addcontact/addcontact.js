// pages/mine/commoninfo/addcontact/addcontact.js
const app = getApp()
const verifyUtils = require("../../../../utils/verifyUtls")
const Request = require("../../../../net/Request")

var isPage = false
var loading = {}
var toast = {}

Component({
  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    idCard: '',
    mob: '',
  },

  lifetimes: {
    attached: function () {
      isPage = false
      loading = this.selectComponent('#loading')
      toast = this.selectComponent('#toast')
      this.setData({
        mob: app.appData.userInfo != null ? app.appData.userInfo.mob : ''
      })
    },
  },

  methods: {
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      isPage = true
      loading = this.selectComponent('#loading')
      toast = this.selectComponent('#toast')
      this.setData({
        mob: app.appData.userInfo != null ? app.appData.userInfo.mob : ''
      })
    },
    saveContact() {
      let name = this.data.name;
      let cardNumber = this.data.idCard;
      if (name.trim().length == 0) {
        toast.show('请输入您的姓名')
        return
      }
      if (!verifyUtils.checkCardLegal(cardNumber, (msg) => {
          toast.show(msg)
        })) {
        return
      }
      if (!verifyUtils.isMobilePhone(this.data.mob)) {
        toast.show('请正确输入您的手机号')
        return
      }
      //请求添加联系人接口
      loading.showLoading()
      Request.addContact({
        linkman: this.data.name,
        idCard: this.data.idCard,
        mob: this.data.mob,
      }, (data) => {
        loading.dismissLoading()
        let pages = getCurrentPages();
        if (isPage) {
          let prevPage = pages[pages.length - 2];
          prevPage.getContactList(false)
          prevPage.showToast("保存成功")
          wx.navigateBack({})
        } else {
          let currPage = pages[pages.length - 1];
          currPage.getContactList(false)
          currPage.showToast("保存成功")
        }
      }, (errMsg) => {
        loading.dismissLoading()
        toast.show(errMsg.errorMsg)
      })
    },
    nameInput(e) {
      this.data.name = e.detail.value
    },
    cardInput(e) {
      this.data.idCard = e.detail.value
    },
    mobInput(e) {
      this.data.mob = e.detail.value
    },
  }
})