// pages/mine/myorder/myorder.js
const app = getApp()
const Request = require("../../../net/Request")

var loading = {}
var toast = {}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    orders: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
  },
  onReady: function () {
    var that = this
    loading.showLoading()
    Request.getMyOrderList({}, (myOrderList) => {
      myOrderList.rows.forEach((order, index) => {
        myOrderList.rows[index].startTime = order.startTime.substring(0, 10)
        myOrderList.rows[index] = {
          ...myOrderList.rows[index],
          roomImg: order.imagePath != null && order.imagePath.length > 0 ? order.imagePath.split(',')[0] : ''
        }
      })
      that.setData({
        orders: myOrderList.rows
      })
      loading.dismissLoading()
    }, (errMsg) => {
      loading.dismissLoading()
      toast.show(errMsg.errorMsg)
    })
  },
  itemtap(e) {
    var index = e.currentTarget.dataset.index;
    let hotelOrder = this.data.orders[index]
    if (Number.parseInt(hotelOrder.hotelStatus) !== 1) {
      toast.show("该酒店已下架")
      return
    }
    wx.navigateTo({
      url: '../../homepage/hotelDetail/hotelDetail?hotelNo=' + hotelOrder.hotelId + '&checkInTime=' + hotelOrder.startTime + '&leaveTime=' + hotelOrder.endTime,
    })
  }
})