// pages/mine/favorite/favorite.js
const app = getApp()
const Request = require("../../../net/Request")

var cancelRemindPop = {}
var loading = {}
var toast = {}

var isReturnBack = false

Page({
  /**
   * 页面的初始数据
   */
  data: {
    collectedHotelList: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    cancelRemindPop = this.selectComponent('#cancelRemindPop')
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
  },
  onReady: function () {
    loading.showLoading()
    this.loadCollectionList()
  },
  onShow: function () {
    if (isReturnBack) {
      this.loadCollectionList()
    }
  },
  onHide: function () {
    isReturnBack = true
  },
  loadCollectionList() {
    var that = this
    Request.getMyCollectionList({}, (collectionList) => {
      that.setData({
        collectedHotelList: collectionList.rows
      })
      loading.dismissLoading()
    }, (errMsg) => {
      loading.dismissLoading()
      toast.show(errMsg.errorMsg)
    })
  },
  cancelCollection(res) {
    var that = this;
    var index = res.currentTarget.dataset.index;
    let hotelNo = this.data.collectedHotelList[index].hotelNo;
    cancelRemindPop.showPop({
      needTitle: false,
      content: '请确认是否取消收藏？',
      cancelText: '取消',
      sureText: '确定'
    }, () => {
      loading.showLoading()
      Request.cancelCollectedHotel({
        hotelNo: hotelNo
      }, () => {
        loading.dismissLoading()
        //删除该元素
        that.data.collectedHotelList.splice(index, 1)
        //刷新列表
        that.setData({
          collectedHotelList: that.data.collectedHotelList
        })
      }, (errMsg) => {
        loading.dismissLoading()
        toast.show(errMsg.errorMsg)
      })
    })
  },
  //跳转到腾讯地图导航
  mapNavigation(res) {
    var index = res.currentTarget.dataset.index;
    var collection = this.data.collectedHotelList[index]
    wx.navigateTo({
      url: '../../homepage/hotelDetail/map/map?addressName=' + collection.detailedAddress + '&longitude=' + collection.longitude + '&latitude=' + collection.latitude,
    })
  },
  itemtap(res) {
    let index = res.currentTarget.dataset.index;
    let collectedHotel = this.data.collectedHotelList[index]
    if (Number.parseInt(collectedHotel.status) !== 1) {
      toast.show("该酒店已下架")
      return
    }
    wx.navigateTo({
      url: '../../homepage/hotelDetail/hotelDetail?hotelNo=' + collectedHotel.hotelNo,
    })
  }
})