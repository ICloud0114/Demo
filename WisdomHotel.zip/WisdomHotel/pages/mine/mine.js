// pages/mine/minepage/minepage.js
const app = getApp()
var unloginPop = {}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    islogin: app.appData.userInfo != null,
    nickName: app.getNickName(),
    avatarUrl: app.getAvatarUrl(),
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    unloginPop = this.selectComponent("#unloginPop")
  },
  onShow: function () {
    if (!this.data.islogin && app.appData.userInfo != null) {
      this.refreshLogin()
    }
  },
  goMyOrderList() {
    if (app.appData.userInfo != null) {
      wx.navigateTo({
        url: '../mine/myorder/myorder',
      })
    } else {
      this.showLoginRemindPop()
    }
  },
  goMyCollectionList() {
    if (app.appData.userInfo != null) {
      wx.navigateTo({
        url: '../mine/collection/collection',
      })
    } else {
      this.showLoginRemindPop()
    }
  },
  goCommonInfo() {
    if (app.appData.userInfo != null) {
      wx.navigateTo({
        url: '../mine/commoninfo/commoninfo'
      })
    } else {
      this.showLoginRemindPop()
    }
  },
  goAboutUs() {
    wx.navigateTo({
      url: '../mine/aboutus/aboutus',
    })
  },
  login() {
    wx.navigateTo({
      url: '../login/login',
    })
  },
  serviceAgreement() {
    wx.navigateTo({
      url: '../login/agreement/agreement?title=服务协议&type=1',
    })
  },
  privatePolicy() {
    wx.navigateTo({
      url: '../login/agreement/agreement?title=隐私政策&type=2',
    })
  },
  showLoginRemindPop() {
    unloginPop.showPop({
      needTitle: false,
      content: '您还未登录，请登录后再操作',
      cancelText: '取消',
      sureText: '登录'
    }, (res) => {
      wx.navigateTo({
        url: '../login/login',
      })
    })
  },
  callService() {
    wx.makePhoneCall({
      phoneNumber: '0755-2765 1888'
    })
  },
  //从未登录到登录执行此方法刷新页面
  refreshLogin() {
    console.log("mine--用户登录了-->需重新加载数据！")
    this.setData({
      islogin: app.appData.userInfo != null,
      nickName: app.getNickName(),
      avatarUrl: app.getAvatarUrl(),
    })
  }
})