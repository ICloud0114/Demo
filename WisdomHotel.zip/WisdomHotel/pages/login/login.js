// pages/phone_login/phone_login.js
const app = getApp()
const Request = require("../../net/Request")

var loading = {}
var toast = {}

var wxLoginParams = {
  jsCode: '',
  encryptedData: '',
  iv: '',
  avatarUrl: '',
  userName: ''
}

Page({
  /**
   * 页面的初始数据
   */
  data: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
    var that = this
    wx.login({
      success: (res) => {
        wxLoginParams.jsCode = res.code
        console.log('jscode=' + res.code)
        that.getSetting()
      },
      fail: () => {
        toast.show("微信登录失败")
      }
    })
  },
  // 获取用户授权
  getSetting(){
    var that = this
    // 可以通过 wx.getSetting 先查询一下用户是否授权了 "scope.userInfo" 
    // 获取用户的当前设置。返回值中只会出现小程序已经向用户请求过的权限。
    wx.getSetting({
      success(res) {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          console.log("获取信息")
          that.getUserInfo()
        } else {
          console.log("未授权")
        }
      },
      fail(res) {
        console.log('获取设置信息失败-->' + res.errMsg)
        wx.showToast({
          title: '网络错误',
          icon: 'none',
        })
      }
    })
  },
  /**获取用户信息 */
  getUserInfo() {
    var that = this
    // 必须是在用户已经授权的情况下调用
    wx.getUserInfo({
      withCredentials: true,
      success: function (res) {
        console.log('test' + '用户信息' + JSON.stringify(res))
        that.wxLoginParams.avatarUrl = res.avatarUrl
        that.wxLoginParams.userName = res.nickName
      }
    })
  },
  // 微信授权登录
  wxLogin(res) {
    var that = this;
    if (res !== undefined && res != null) {
      let userInfo = res.detail.userInfo
      if (userInfo !== undefined && userInfo != null) {
        console.log('获取到的用户信息为==>' + JSON.stringify(userInfo))
        wxLoginParams.avatarUrl = userInfo.avatarUrl
        wxLoginParams.userName = userInfo.nickName
      }
      wx.login({
        success: (res) => {
          wxLoginParams.jsCode = res.code
          console.log('jscode=' + res.code)
          //执行登录
          loading.showLoading()
          Request.wxUserOneKeyLogin(wxLoginParams, (userInfo) => {
            //保存用户信息到全局
            app.appData.userInfo = userInfo
            //关闭登录相关页面回到原先的页面
            let pages = getCurrentPages();
            let originalPage = pages[pages.length - 2]; //需返回两页到原始页面
            originalPage.refreshLogin() //刷新原始页面
            //关闭加载弹窗
            loading.dismissLoading()
            //回退到原始页面
            wx.navigateBack({
              delta: 1
            })
          }, (errMsg) => {
            loading.dismissLoading()
            //尚未绑定手机号，去绑定手机号
            if (errMsg.errorCode === 201306) {
              that.phoneLogin()
            } else {
              toast.show(errMsg.errorMsg)
            }
          })
          wx.getUserInfo({
            withCredentials: true,
            success: function (res) {
              console.log('test' + '用户信息' + JSON.stringify(res))
              console.log('iv -->' + res.iv)
              console.log('encryptedData -->' + res.encryptedData)
              // getApp().data.userInfo = res.userInfo;
              console.log("获取用户信息成功，返回上一级");
              // that.getToken(res);
            }
          })

        },
        fail: () => {
          toast.show("微信授权失败")
        }
      })
    }
  },
  // 获取用户绑定微信手机
  getPhoneNumber(e) {
    console.log(e.detail.errMsg)
    console.log(e.detail.iv)
    console.log(e.detail.encryptedData)
    wx.checkSession({
      success: (res) => {
        
      },
      fail () {
        wx.login({
          success: (res) =>{
            if (res.code) {

            }
          },
          fail: () =>{

          }
        }) //重新登录
      }
    })
  },
  // 手机验证登录
  phoneLogin() {
    wx.navigateTo({
      url: './phonelogin/phonelogin',
    })
  },
  serviceAgreement() {
    wx.navigateTo({
      url: '../login/agreement/agreement?title=服务协议&type=1',
    })
  },
  privatePolicy() {
    wx.navigateTo({
      url: '../login/agreement/agreement?title=隐私政策&type=2',
    })
  }
})