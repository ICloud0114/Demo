// pages/login/unbind_phone/unbind_phone.js
const app = getApp()
const verifyUtils = require("../../../utils/verifyUtls")
const Request = require("../../../net/Request")

var loading = {}
var toast = {}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    codeDis: false, // true 获取验证码不可点
    loginDis: true, //true 登陆按钮不可点
    downCount: 60,
    phoneCodetext: "获取验证码",
    phone: "", //输入的号码
    verificationCode: "", //输入的验证码
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    loading = this.selectComponent('#loading')
    toast = this.selectComponent('#toast')
  },
  onUnload: function () {
    clearInterval()
  },
  login() {
    if (this.data.loginDis) {
      return
    }
    let phone = this.data.phone;
    let code = this.data.verificationCode;
    //手机验证登录
    loading.showLoading()
    wx.login({
      success: (res) => {
        Request.phoneVerifyLogin({
          mob: phone,
          code: code,
          jsCode: res.code
        }, (userInfo) => {
          //保存用户信息到全局
          app.appData.userInfo = userInfo
          //关闭登录相关页面回到原先的页面
          let pages = getCurrentPages();
          let originalPage = pages[pages.length - 3]; //需返回两页到原始页面
          originalPage.refreshLogin() //刷新原始页面
          //关闭加载弹窗
          loading.dismissLoading()
          //回退到原始页面
          wx.navigateBack({
            delta: 2
          })
        }, (errMsg) => {
          loading.dismissLoading()
          toast.show(errMsg.errorMsg)
        })
      },
      fail: (err) => {
        loading.dismissLoading()
        toast.show('登录失败')
      }
    })
  },
  sendCode(e) {
    var that = this;
    let phone = this.data.phone;
    if (!verifyUtils.isMobilePhone(phone)) {
      toast.show('请输入正确的手机号')
      return;
    }
    //获取验证码
    loading.showLoading()
    Request.getVerificationCode({
      mob: phone
    }, (data) => {
      loading.dismissLoading()
      toast.show('验证码已发送')
      //设置发送验证的按钮
      that.setCountDown()
    }, (errMsg) => {
      loading.dismissLoading()
      toast.show(errMsg.errorMsg)
    })
  },
  setCountDown() {
    var that = this;
    var downCount = this.data.downCount
    this.setData({
      codeDis: true,
      downCount: downCount,
      phoneCodetext: '重新发送(' + downCount + ')',
    })
    let time = setInterval(() => {
      downCount--
      that.setData({
        codeDis: true,
        downCount: downCount,
        phoneCodetext: '重新发送(' + downCount + ')',
      })
      if (downCount == 0) {
        clearInterval(time)
        that.setData({
          phoneCodetext: "获取验证码",
          downCount: 60,
          codeDis: false
        })
      }
    }, 1000);
  },
  phoneInput(res) {
    let value = res.detail.value
    this.setData({
      phone: value
    })
    this.checkLegal();
  },
  codeInput(res) {
    let value = res.detail.value
    this.setData({
      verificationCode: value
    })
    this.checkLegal();
  },
  checkLegal() {
    let code = this.data.verificationCode;
    let phone = this.data.phone;
    if (!isNaN(code) && !isNaN(phone)) {
      let flags = verifyUtils.isMobilePhone(phone);
      if (flags && phone.length == 11 && code.length == 4) {
        this.setData({
          loginDis: false
        })
      } else {
        this.setData({
          loginDis: true
        })
      }
    } else {
      this.setData({
        loginDis: true
      })
    }
  },
  serviceAgreement() {
    wx.navigateTo({
      url: '../agreement/agreement?title=服务协议&type=1',
    })
  },
  privatePolicy() {
    wx.navigateTo({
      url: '../agreement/agreement?title=隐私政策&type=2',
    })
  }
})