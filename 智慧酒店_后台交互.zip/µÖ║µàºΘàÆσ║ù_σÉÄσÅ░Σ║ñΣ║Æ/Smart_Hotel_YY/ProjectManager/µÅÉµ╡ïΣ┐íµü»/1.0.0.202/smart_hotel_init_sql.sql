/*
SQLyog Professional v12.09 (64 bit)
MySQL - 5.7.22-0ubuntu0.16.04.1 : Database - smart_hotel
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`smart_hotel` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `smart_hotel`;

/*Table structure for table `h_hotel` */

DROP TABLE IF EXISTS `h_hotel`;

CREATE TABLE `h_hotel` (
  `hotel_id` varchar(32) NOT NULL COMMENT '酒店id',
  `hotel_name` varchar(100) DEFAULT '' COMMENT '酒店名称',
  `hotel_url` varchar(100) DEFAULT '' COMMENT '酒店网址',
  `phone` varchar(20) DEFAULT NULL COMMENT '酒店电话',
  `detailed_address` varchar(200) DEFAULT '' COMMENT '酒店地址',
  `level` varchar(20) DEFAULT NULL COMMENT '酒店评级',
  `facilities` varchar(500) DEFAULT NULL COMMENT '酒店设施',
  `longitude` double DEFAULT NULL COMMENT '经度',
  `latitude` double DEFAULT NULL COMMENT '纬度',
  `province` varchar(30) DEFAULT NULL COMMENT '省',
  `city` varchar(30) DEFAULT NULL COMMENT '市',
  `prefecture` varchar(20) DEFAULT NULL COMMENT '县、区',
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '二维码路径',
  `detail` varchar(5000) DEFAULT NULL COMMENT '酒店详情',
  `status` int(11) DEFAULT NULL COMMENT '酒店状态 0.下架 1.上架 默认为0',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  `hotel_pic` varchar(100) DEFAULT NULL COMMENT '酒店照片',
  `create_by` varchar(255) DEFAULT NULL COMMENT '创建者',
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='酒店.';

/*Data for the table `h_hotel` */

/*Table structure for table `h_hotel_image` */

DROP TABLE IF EXISTS `h_hotel_image`;

CREATE TABLE `h_hotel_image` (
  `id` varchar(32) NOT NULL COMMENT '照片id',
  `image_name` varchar(200) DEFAULT NULL COMMENT '图片原始名',
  `image_path` varchar(200) DEFAULT NULL COMMENT '上传云端的相对路径',
  `hotel_id` varchar(32) DEFAULT NULL COMMENT '酒店id，来自h_hotel的hotel_id',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0' COMMENT '0-正常，1-已删除',
  `sort` int(1) DEFAULT NULL COMMENT '图片序号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='酒店图片.';

/*Data for the table `h_hotel_image` */

/*Table structure for table `h_room_category` */

DROP TABLE IF EXISTS `h_room_category`;

CREATE TABLE `h_room_category` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `room_style` varchar(100) DEFAULT NULL COMMENT '房型风格如豪华,商务，普通',
  `type_name` varchar(100) DEFAULT NULL COMMENT '房型',
  `hotel_id` varchar(32) DEFAULT NULL COMMENT '酒店id，来自h_hotel的hotel_id',
  `room_pic` varchar(100) DEFAULT NULL COMMENT '房型照片',
  `original_price` decimal(15,2) DEFAULT '0.00' COMMENT '原价, 单位: 元.',
  `vip_price` decimal(15,2) DEFAULT '0.00' COMMENT '会员价, 单位: 元.',
  `status` int(11) DEFAULT '0' COMMENT '酒店状态 0.下架 1.上架',
  `detail` varchar(200) DEFAULT NULL COMMENT '房型说明',
  `del_flag` int(1) DEFAULT '0' COMMENT '0-正常，1-删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='房型';

/*Data for the table `h_room_category` */

/*Table structure for table `h_room_image` */

DROP TABLE IF EXISTS `h_room_image`;

CREATE TABLE `h_room_image` (
  `id` varchar(32) NOT NULL COMMENT '照片id',
  `image_name` varchar(200) DEFAULT NULL COMMENT '图片原始名',
  `image_path` varchar(200) DEFAULT NULL COMMENT '上传云端的相对路径',
  `room_id` varchar(32) DEFAULT NULL COMMENT '房型id，来自h_room_category的id',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `del_flag` int(4) DEFAULT NULL COMMENT '0-正常，1-已删除',
  `sort` int(1) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房型图片.';

/*Data for the table `h_room_image` */

/*Table structure for table `o_order` */

DROP TABLE IF EXISTS `o_order`;

CREATE TABLE `o_order` (
  `id` varchar(32) NOT NULL COMMENT '主键.订单编号',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间.',
  `member_id` varchar(32) DEFAULT NULL COMMENT '会员id',
  `person_num` int(11) DEFAULT NULL COMMENT '人数.',
  `booker_id` varchar(32) DEFAULT NULL COMMENT '预订人为联系人时用',
  `booker_name` varchar(64) DEFAULT NULL COMMENT '预订人.',
  `booker_phone` varchar(20) DEFAULT NULL COMMENT '预订人手机号',
  `start_time` datetime DEFAULT NULL COMMENT '入住时间.',
  `end_time` datetime DEFAULT NULL COMMENT '离店时间.',
  `arrival_time` datetime DEFAULT NULL COMMENT '到店时间.',
  `money` decimal(15,2) DEFAULT NULL COMMENT '订单金额, 单位: 元.',
  `status` int(1) DEFAULT '-1' COMMENT '状态,-2:预订失败-1:待付款 0：已付款, 1: 已拒绝,2：已确认,3-取消',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标志, 0: 表示正常使用的数据, 1: 表示已删除的数据.',
  `create_by` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人ID.',
  `update_by` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人ID.',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `hotel_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表.';

/*Data for the table `o_order` */

/*Table structure for table `o_order_room_category` */

DROP TABLE IF EXISTS `o_order_room_category`;

CREATE TABLE `o_order_room_category` (
  `order_id` varchar(32) NOT NULL COMMENT '来自o_order表的id字段.',
  `category_id` varchar(32) NOT NULL COMMENT '来自h_hotel_room_category表的id字段.',
  `del_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  `room_number` int(1) DEFAULT NULL,
  `original_price` decimal(15,2) DEFAULT NULL,
  `vip_price` decimal(15,2) DEFAULT NULL,
  `room_style` varchar(100) DEFAULT NULL,
  `type_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`order_id`,`category_id`),
  KEY `order_id` (`order_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单酒店房型关系表.';

/*Data for the table `o_order_room_category` */

/*Table structure for table `o_pay_order` */

DROP TABLE IF EXISTS `o_pay_order`;

CREATE TABLE `o_pay_order` (
  `id` varchar(32) NOT NULL,
  `nonce_str` varchar(32) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `is_subcribe` varchar(1) DEFAULT NULL COMMENT 'Y-关注，N-未关注',
  `trade_type` varchar(16) DEFAULT NULL,
  `bank_type` varchar(32) DEFAULT NULL,
  `total_free` int(11) DEFAULT NULL,
  `cash_fee` int(11) DEFAULT NULL,
  `transaction_id` varchar(32) DEFAULT NULL COMMENT '微信支付订单号',
  `out_trade_no` varchar(32) DEFAULT NULL COMMENT '商户系统内部订单号',
  `time_end` varchar(14) DEFAULT NULL COMMENT '支付完成时间，格式为yyyyMMddHHmmss',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `del_flag` int(1) DEFAULT NULL,
  `open_id` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `o_pay_order` */

/*Table structure for table `o_wxpay_refund` */

DROP TABLE IF EXISTS `o_wxpay_refund`;

CREATE TABLE `o_wxpay_refund` (
  `id` varchar(32) NOT NULL COMMENT '唯一主键，商户退款单号',
  `transaction_id` varchar(32) NOT NULL COMMENT '微信订单号',
  `out_trade_no` varchar(32) NOT NULL COMMENT '商户订单号',
  `total_fee` decimal(10,2) NOT NULL COMMENT '订单金额',
  `refund_fee` decimal(10,2) NOT NULL COMMENT '退款金额',
  `refund_fee_type` varchar(8) DEFAULT NULL COMMENT '货币种类',
  `refund_desc` varchar(128) DEFAULT NULL COMMENT '退款原因',
  `refund_account` varchar(32) DEFAULT NULL COMMENT '退款资金来源',
  `notify_url` varchar(256) DEFAULT NULL COMMENT '退款结果通知url',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-待退款 1-退款中 2-退款失败 3-退款成功',
  `op_user_id` varchar(32) DEFAULT NULL COMMENT '操作员',
  `del_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已删除',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信退款表';

/*Data for the table `o_wxpay_refund` */

/*Table structure for table `sys_resource` */

DROP TABLE IF EXISTS `sys_resource`;

CREATE TABLE `sys_resource` (
  `id` varchar(32) NOT NULL COMMENT '主键.',
  `name` varchar(100) DEFAULT '' COMMENT '菜单/功能点名称.',
  `parent_id` varchar(32) NOT NULL DEFAULT '0' COMMENT '父节点ID, 一级节点的父节点ID为0, 默认为0.',
  `tree_no` tinyint(4) DEFAULT NULL COMMENT '1产品无关树，2产品相关树',
  `resource_type` tinyint(4) DEFAULT '1' COMMENT '资源类型, 1权限，2产品类型，3产品',
  `parent_ids` varchar(2000) DEFAULT NULL COMMENT '所有父级编号, 用英文逗号分隔',
  `description` varchar(100) DEFAULT '' COMMENT '描述, 对菜单/功能点名称的补充说明.',
  `permission` varchar(100) DEFAULT '' COMMENT '权限名称，用于权限验证.',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '该权限是否默认分配给角色',
  `add_all_children` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要将子权限全部加入到sys_role_resource',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示(1: 显示, 2: 不显示, 默认为1.).',
  `url` varchar(500) DEFAULT '' COMMENT '请求资源的URL，当为菜单叶子时必须填写.当resource_type=2是为产品类型id，当resource_type=3时为产品id',
  `icon` varchar(100) DEFAULT NULL COMMENT '图标',
  `order_no` smallint(4) NOT NULL DEFAULT '1' COMMENT '排序.',
  `sys_type` tinyint(1) DEFAULT NULL COMMENT '系统资源类型，1：产品管理',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间.',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `del_flag` tinyint(1) DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限表.';

/*Data for the table `sys_resource` */

insert  into `sys_resource`(`id`,`name`,`parent_id`,`tree_no`,`resource_type`,`parent_ids`,`description`,`permission`,`is_default`,`add_all_children`,`is_show`,`url`,`icon`,`order_no`,`sys_type`,`create_time`,`update_time`,`del_flag`,`role_type`) values ('1684211285b340f6a7eaaafe84da661b','新闻动态管理','1d71790fce734ddba166ecf7f2b5e021',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021','新闻动态管理','',0,0,1,'/manage/news/list',NULL,2,NULL,'2020-06-18 11:12:53','2020-06-18 11:12:53',0,1),('17b27bdb475d45eaa6c86b3ec785a951','加载权限菜单','495fb637b46111eaad61005056b853d4',1,1,'d9df10c0b55441f481877968f322a250,495fb637b46111eaad61005056b853d4','登录成功加载权限菜单','',0,0,1,'/userlogin/loginsuccess',NULL,1,NULL,'2020-06-22 14:16:39','2020-06-22 14:16:39',1,1),('1a5f619d756f40fe899bc7d57ad97e0e','上架/下架','1684211285b340f6a7eaaafe84da661b',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,1684211285b340f6a7eaaafe84da661b','上架/下架动态新闻','',0,0,1,'/manage/news/putaway',NULL,3,NULL,'2020-06-18 11:30:58','2020-06-18 11:30:58',0,1),('1d71790fce734ddba166ecf7f2b5e021','门户管理','73bad8e237ad40a6acceff5ba6590cd2',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2','门户管理','',0,0,1,'/manage/banner/imageList,/manage/news/list,/common/image/upload',NULL,1,NULL,'2020-06-18 11:01:43','2020-06-18 11:01:43',0,1),('2551e8ae487e469c81f4cc69e09f0514','新增','ed837adadaca47a682054ec0d89c8822',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,ed837adadaca47a682054ec0d89c8822','新增酒店管理员','',0,0,1,'/hotel/user/add,/hotel/list,/sys/role/list',NULL,2,NULL,'2020-06-18 10:52:00','2020-06-18 10:52:00',0,0),('255207c9332e4dc98cec489efdbc9287','会员管理','2ed1198871ff4a65b47121cb9835c3d2',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d2','会员管理','',0,0,1,'/vip/list',NULL,1,NULL,'2020-06-18 09:44:43','2020-06-18 09:44:43',0,1),('261e4f84e39c4d62a004142fac2cb7ca','搜索','ed837adadaca47a682054ec0d89c8822',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,ed837adadaca47a682054ec0d89c8822','搜索酒店管理员','',0,0,1,'/hotel/user/list',NULL,1,NULL,'2020-06-18 10:43:42','2020-06-18 10:43:42',1,0),('2ed1198871ff4a65b47121cb9835c3a0','酒店订单','2ed1198871ff4a65b47121cb9835c3d3',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3','','',1,0,1,'/order/list,/order/confirm,/order/wx/refund',NULL,1,NULL,'2020-06-17 11:04:17','2020-06-17 11:04:17',0,0),('2ed1198871ff4a65b47121cb9835c3a1','搜索','2ed1198871ff4a65b47121cb9835c3a0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3a0','订单搜索','',0,0,1,'/order/list',NULL,1,NULL,'2020-06-17 11:16:30','2020-06-17 11:16:30',1,0),('2ed1198871ff4a65b47121cb9835c3a2','确认/拒绝订单','2ed1198871ff4a65b47121cb9835c3a0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3a0','','',0,0,1,'/order/confirm',NULL,2,NULL,'2020-06-17 11:17:20','2020-06-17 11:17:20',0,0),('2ed1198871ff4a65b47121cb9835c3a3','拒绝订单','2ed1198871ff4a65b47121cb9835c3a0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3a0','','',0,0,1,'/order/confirm',NULL,3,NULL,'2020-06-17 11:18:17','2020-06-17 11:18:17',1,0),('2ed1198871ff4a65b47121cb9835c3a4','退款','2ed1198871ff4a65b47121cb9835c3a0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3a0','','',0,0,1,'/order/wx/refund',NULL,4,NULL,'2020-06-17 11:20:02','2020-06-17 11:20:02',0,0),('2ed1198871ff4a65b47121cb9835c3b0','酒店管理','2ed1198871ff4a65b47121cb9835c3d1',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1','','',0,0,1,'/hotel/list,/hotel/add,/hotel/detail,/hotel/edit,/hotel/onoff',NULL,1,NULL,'2020-06-17 11:22:25','2020-06-17 11:22:25',0,0),('2ed1198871ff4a65b47121cb9835c3b1','新增酒店','2ed1198871ff4a65b47121cb9835c3b0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3b0','','',0,0,1,'/hotel/add,/common/image/upload,/common/image/delete',NULL,1,NULL,'2020-06-17 11:28:23','2020-06-17 11:28:23',0,0),('2ed1198871ff4a65b47121cb9835c3b2','搜索','2ed1198871ff4a65b47121cb9835c3b0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3b0','酒店搜索','',0,0,1,'/hotel/list',NULL,2,NULL,'2020-06-17 11:30:05','2020-06-17 11:30:05',1,0),('2ed1198871ff4a65b47121cb9835c3b3','详情','2ed1198871ff4a65b47121cb9835c3b0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3b0','酒店详情','',0,0,1,'/hotel/detail',NULL,3,NULL,'2020-06-17 11:31:52','2020-06-17 11:31:52',0,0),('2ed1198871ff4a65b47121cb9835c3b4','酒店编辑','2ed1198871ff4a65b47121cb9835c3b0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3b0','','',0,0,1,'',NULL,4,NULL,'2020-06-17 11:32:09','2020-06-17 11:32:09',0,0),('2ed1198871ff4a65b47121cb9835c3b5','上架/下架','2ed1198871ff4a65b47121cb9835c3b0',1,1,'2ed1d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3b0','酒店上架/下架','',0,0,1,'/hotel/onoff',NULL,5,NULL,'2020-06-17 11:32:38','2020-06-17 11:32:38',0,0),('2ed1198871ff4a65b47121cb9835c3b6','下架','2ed1198871ff4a65b47121cb9835c3b0',1,1,'2ed1d9df10c0b55441f481877968f322a250,198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3b0','酒店下架','',0,0,1,'',NULL,6,NULL,'2020-06-17 11:32:55','2020-06-17 11:32:55',1,0),('2ed1198871ff4a65b47121cb9835c3c0','房型管理','2ed1198871ff4a65b47121cb9835c3d1',1,1,'2ed1198871ff4a65b47121cb9835c3d1','','',0,0,1,'/room/list',NULL,1,NULL,'2020-06-17 13:19:48','2020-06-17 13:19:48',0,0),('2ed1198871ff4a65b47121cb9835c3c1','新增房型','2ed1198871ff4a65b47121cb9835c3c0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3c0','','',0,0,1,'/room/add,/room/styleAndType/list',NULL,1,NULL,'2020-06-17 13:21:56','2020-06-17 13:21:56',0,0),('2ed1198871ff4a65b47121cb9835c3c2','上架/下架','2ed1198871ff4a65b47121cb9835c3c0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3c0','房型上架','',0,0,1,'/room/onoff',NULL,2,NULL,'2020-06-17 13:25:38','2020-06-17 13:25:38',0,0),('2ed1198871ff4a65b47121cb9835c3c3','下架','2ed1198871ff4a65b47121cb9835c3c0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3c0','房型下架','',0,0,1,'/room/onoff',NULL,3,NULL,'2020-06-17 13:25:56','2020-06-17 13:25:56',1,0),('2ed1198871ff4a65b47121cb9835c3c4','搜索','2ed1198871ff4a65b47121cb9835c3c0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3c0','房型搜索','',0,0,1,'/room/list',NULL,4,NULL,'2020-06-17 13:26:19','2020-06-17 13:26:19',1,0),('2ed1198871ff4a65b47121cb9835c3c5','编辑','2ed1198871ff4a65b47121cb9835c3c0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d3,2ed1198871ff4a65b47121cb9835c3d1,2ed1198871ff4a65b47121cb9835c3c0','房型编辑','',0,0,1,'/room/detail,/room/edit,/common/image/upload,/common/image/delete,/room/styleAndType/list',NULL,5,NULL,'2020-06-17 13:26:47','2020-06-17 13:26:47',0,0),('2ed1198871ff4a65b47121cb9835c3d1','酒店管理','d9df10c0b55441f481877968f322a250',1,1,'d9df10c0b55441f481877968f322a250','','',1,1,1,'','',2,NULL,'2019-11-30 11:11:23','2019-11-30 11:11:23',0,0),('2ed1198871ff4a65b47121cb9835c3d2','会员管理','d9df10c0b55441f481877968f322a250',1,1,'d9df10c0b55441f481877968f322a250','','',1,1,1,'','',3,NULL,'2019-11-30 11:11:23','2019-11-30 11:11:23',0,1),('2ed1198871ff4a65b47121cb9835c3d3','订单管理','d9df10c0b55441f481877968f322a250',1,1,'d9df10c0b55441f481877968f322a250','','',1,1,1,'','',4,NULL,'2019-11-30 11:11:23','2019-11-30 11:11:23',0,0),('2ed1198871ff4a65b47121cb9835c3d4','系统设置','d9df10c0b55441f481877968f322a250',1,1,'d9df10c0b55441f481877968f322a250','','',1,1,1,'','',5,NULL,'2019-11-30 11:11:23','2019-11-30 11:11:23',0,1),('2ed1198871ff4a65b47121cb9835c3e0','操作日志','2ed1198871ff4a65b47121cb9835c3d4',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4','','',0,0,1,'/log/list',NULL,3,NULL,'2020-06-17 13:32:29','2020-06-17 13:32:29',0,1),('2ed1198871ff4a65b47121cb9835c3e1','搜索','2ed1198871ff4a65b47121cb9835c3e0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,2ed1198871ff4a65b47121cb9835c3e0','日志搜索','',0,0,1,'/log/list',NULL,1,NULL,'2020-06-17 13:33:23','2020-06-17 13:33:23',1,1),('2ed1198871ff4a65b47121cb9835c3e2','重置','2ed1198871ff4a65b47121cb9835c3e0',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,2ed1198871ff4a65b47121cb9835c3e0','重置日志','',0,0,1,'/log/list',NULL,2,NULL,'2020-07-09 17:50:46','2020-07-09 17:50:46',0,1),('36038a2d88ef4dca8eb447b65a118162','新增','1684211285b340f6a7eaaafe84da661b',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,1684211285b340f6a7eaaafe84da661b','新增动态新闻','',0,0,1,'/manage/news/add',NULL,1,NULL,'2020-06-18 11:27:57','2020-06-18 11:27:57',0,1),('495fb637b46111eaad61005056b853d4','登录成功','d9df10c0b55441f481877968f322a250',1,1,'d9df10c0b55441f481877968f322a250','登录成功','',0,0,1,'',NULL,1,NULL,'2020-06-22 16:21:59','2020-06-22 16:21:59',1,1),('4acc230bf3ed4e54abc792e778c762ce','搜索','255207c9332e4dc98cec489efdbc9287',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d2,255207c9332e4dc98cec489efdbc9287','查询会员列表','',0,0,1,'/vip/list',NULL,1,NULL,'2020-06-18 10:10:50','2020-06-18 10:10:50',1,1),('502a00f0471a42cb92ec5e07c7a992f9','搜索','ce9e0130f07a46a9b92620263d116eb6',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,ce9e0130f07a46a9b92620263d116eb6','查询系统用户列表','',0,0,1,'/sys/user/list',NULL,1,NULL,'2020-06-18 09:57:49','2020-06-18 09:57:49',1,1),('5049012ab46111eaad61005056b853d4','退出登录','495fb637b46111eaad61005056b853d4',1,1,'d9df10c0b55441f481877968f322a250,495fb637b46111eaad61005056b853d4','退出登录','',0,0,1,'/userlogin/logout',NULL,2,NULL,'2020-06-22 16:22:50','2020-06-22 16:22:50',1,1),('566d0b302acd4a8ab56865006fd6a3ce','编辑','ce9e0130f07a46a9b92620263d116eb6',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,ce9e0130f07a46a9b92620263d116eb6','编辑系统用户','',0,0,1,'/sys/user/edit,/sys/user/detail',NULL,3,NULL,'2020-06-18 09:59:30','2020-06-18 09:59:30',0,1),('57080094350a49e7b35d75f3b7cc7c42','删除','1684211285b340f6a7eaaafe84da661b',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,1684211285b340f6a7eaaafe84da661b','删除动态新闻','',0,0,1,'/manage/news/delete',NULL,4,NULL,'2020-06-18 11:31:01','2020-06-18 11:31:01',0,1),('5b088ed6338f43ab97219f3293ef09a2','角色管理','2ed1198871ff4a65b47121cb9835c3d4',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4','角色管理','',0,0,1,'/sys/role/list',NULL,2,NULL,'2020-06-18 10:21:57','2020-06-18 10:21:57',0,1),('5c40cdf80b144c639394663867da4fa2','新增','deb80bf096344b178833bbae868b01a4',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,deb80bf096344b178833bbae868b01a4','新增轮播图','',0,0,1,'/manage/banner/addImage',NULL,1,NULL,'2020-06-18 11:15:56','2020-06-18 11:15:56',0,1),('5fae9bf29f4f42c1ae5bc99a9302b586','新增','ce9e0130f07a46a9b92620263d116eb6',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,ce9e0130f07a46a9b92620263d116eb6','新增系统用户','',0,0,1,'/sys/user/add',NULL,2,NULL,'2020-06-18 09:57:51','2020-06-18 09:57:51',0,1),('6ca1474532ed4bfebc2f32426443f69b','编辑','ed837adadaca47a682054ec0d89c8822',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,ed837adadaca47a682054ec0d89c8822','编辑酒店管理员','',0,0,1,'/hotel/user/edit,/hotel/user/detail,/hotel/list,/sys/role/list',NULL,3,NULL,'2020-06-18 10:44:23','2020-06-18 10:44:23',0,0),('73bad8e237ad40a6acceff5ba6590cd2','运营管理','d9df10c0b55441f481877968f322a250',1,1,'d9df10c0b55441f481877968f322a250','运营管理','',0,0,1,'',NULL,6,NULL,'2020-06-18 11:01:08','2020-06-18 11:01:08',0,1),('7f6090b2da0d4ee298cb61148deb9cff','修改密码','ed837adadaca47a682054ec0d89c8822',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,ed837adadaca47a682054ec0d89c8822','修改酒店管理员密码','',0,0,1,'/hotel/user/editPassword',NULL,4,NULL,'2020-06-18 10:44:49','2020-06-18 10:44:49',0,0),('8f71bc7250be4d169bf80574088f3b86','删除','deb80bf096344b178833bbae868b01a4',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,deb80bf096344b178833bbae868b01a4','删除轮播图','',0,0,1,'/manage/banner/deleteImage',NULL,4,NULL,'2020-06-18 11:19:25','2020-06-18 11:19:25',0,1),('a6fc9673009e4605a74098ce40204e7e','修改密码','ce9e0130f07a46a9b92620263d116eb6',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,ce9e0130f07a46a9b92620263d116eb6','修改系统密码','',0,0,1,'/sys/user/editPassword',NULL,5,NULL,'2020-06-18 09:59:09','2020-06-18 09:59:09',0,1),('b57ee356e95e47329ae59bf18dba8c80','删除','5b088ed6338f43ab97219f3293ef09a2',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,5b088ed6338f43ab97219f3293ef09a2','删除角色','',0,0,1,'/sys/role/remove',NULL,3,NULL,'2020-06-18 10:24:01','2020-06-18 10:24:01',0,1),('b98edca6a7ff4af4a93a56f7ed8ea6e8','删除','ed837adadaca47a682054ec0d89c8822',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1,ed837adadaca47a682054ec0d89c8822','删除酒店管理员','',0,0,1,'/hotel/user/del',NULL,5,NULL,'2020-06-18 10:44:52','2020-06-18 10:44:52',0,0),('bc052c540b214c7b9b30d1f2d1def642','删除','ce9e0130f07a46a9b92620263d116eb6',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,ce9e0130f07a46a9b92620263d116eb6','删除系统用户','',0,0,1,'/sys/user/del',NULL,5,NULL,'2020-06-18 10:00:13','2020-06-18 10:00:13',0,1),('bff10e36dc5a46c39c07745c96db02d3','新增','5b088ed6338f43ab97219f3293ef09a2',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,5b088ed6338f43ab97219f3293ef09a2','新增角色','',0,0,1,'/sys/role/add,/sys/role/resource/all',NULL,1,NULL,'2020-06-18 10:23:38','2020-06-18 10:23:38',0,1),('c609da8994e34edb9db156c9e220395a','编辑','deb80bf096344b178833bbae868b01a4',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,deb80bf096344b178833bbae868b01a4','编辑轮播图','',0,0,1,'/manage/banner/editImage,/manage/banner/imageDetail',NULL,2,NULL,'2020-06-18 11:18:22','2020-06-18 11:18:22',0,1),('ce9e0130f07a46a9b92620263d116eb6','系统用户管理','2ed1198871ff4a65b47121cb9835c3d4',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4','系统用户管理','',0,0,1,'/sys/user/list',NULL,1,NULL,'2020-06-18 09:53:12','2020-06-18 09:53:12',0,1),('d9df10c0b55441f481877968f322a250','root','0',1,1,'','根节点','',0,0,1,'/userlogin/loginsuccess,/userlogin/logout','',1,NULL,'2019-11-03 17:50:51','2019-11-03 17:50:51',0,1),('deb80bf096344b178833bbae868b01a4','首页轮播管理','1d71790fce734ddba166ecf7f2b5e021',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021','首页轮播管理','',0,0,1,'/manage/banner/imageList',NULL,1,NULL,'2020-06-18 11:10:22','2020-06-18 11:10:22',0,1),('e7be59ee511c4fe0b56e8c2e1aab45aa','上架/下架','deb80bf096344b178833bbae868b01a4',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,deb80bf096344b178833bbae868b01a4','上架/下架轮播图','',0,0,1,'/manage/banner/putawayImage',NULL,3,NULL,'2020-06-18 11:19:16','2020-06-18 11:19:16',0,1),('ed837adadaca47a682054ec0d89c8822','酒店管理员','2ed1198871ff4a65b47121cb9835c3d1',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d1','酒店管理员','',0,0,1,'/hotel/user/list',NULL,3,NULL,'2020-06-18 10:42:48','2020-06-18 10:42:48',0,0),('f45ae37715ce4124a46e3164bf0c2ac9','编辑','1684211285b340f6a7eaaafe84da661b',1,1,'d9df10c0b55441f481877968f322a250,73bad8e237ad40a6acceff5ba6590cd2,1d71790fce734ddba166ecf7f2b5e021,1684211285b340f6a7eaaafe84da661b','编辑动态新闻','',0,0,1,'/manage/news/edit,/manage/news/detail',NULL,2,NULL,'2020-06-18 11:30:52','2020-06-18 11:30:52',0,1),('f9f72142dd344952bce7e77ac3db73c9','编辑','5b088ed6338f43ab97219f3293ef09a2',1,1,'d9df10c0b55441f481877968f322a250,2ed1198871ff4a65b47121cb9835c3d4,5b088ed6338f43ab97219f3293ef09a2','编辑角色','',0,0,1,'/sys/role/edit,/sys/role/resource/all,/sys/role/detail',NULL,2,NULL,'2020-06-18 10:23:53','2020-06-18 10:23:53',0,1);


/*Table structure for table `sys_role` */

DROP TABLE IF EXISTS `sys_role`;

CREATE TABLE `sys_role` (
  `id` varchar(32) NOT NULL COMMENT '主键.',
  `name` varchar(30) NOT NULL COMMENT '角色名称.',
  `role_type` int(11) DEFAULT NULL COMMENT '角色类别, 0: 酒店 1：拓邦 默认：0',
  `order_no` int(3) NOT NULL DEFAULT '1' COMMENT '排序.',
  `create_by` varchar(32) DEFAULT NULL COMMENT '创建人ID.',
  `update_by` varchar(32) DEFAULT NULL COMMENT '修改人ID.',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间.',
  `del_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表.';

/*Data for the table `sys_role` */

insert  into `sys_role`(`id`,`name`,`role_type`,`order_no`,`create_by`,`update_by`,`update_time`,`create_time`,`del_flag`) values ('76fb9708a3ee11eaad61005056b853d4','拓邦管理员角色',1,1,'7f860950a3ee11eaad61005056b853d4','e467744794694ee8a3e54f33e1334ef0','2020-06-22 16:29:16','2020-06-01 18:02:16',0);

/*Table structure for table `sys_role_resource` */

DROP TABLE IF EXISTS `sys_role_resource`;

CREATE TABLE `sys_role_resource` (
  `role_id` varchar(32) NOT NULL COMMENT '来自sys_role表的id字段.',
  `resource_id` varchar(32) NOT NULL COMMENT '来自sys_resource表的id字段.',
  `del_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  PRIMARY KEY (`role_id`,`resource_id`),
  KEY `role_id` (`role_id`),
  KEY `resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色权限关系表.';

/*Data for the table `sys_role_resource` */

insert  into `sys_role_resource`(`role_id`,`resource_id`,`del_flag`) values ('76fb9708a3ee11eaad61005056b853d4','1684211285b340f6a7eaaafe84da661b',0),('76fb9708a3ee11eaad61005056b853d4','17b27bdb475d45eaa6c86b3ec785a951',0),('76fb9708a3ee11eaad61005056b853d4','1a5f619d756f40fe899bc7d57ad97e0e',0),('76fb9708a3ee11eaad61005056b853d4','1d71790fce734ddba166ecf7f2b5e021',0),('76fb9708a3ee11eaad61005056b853d4','2551e8ae487e469c81f4cc69e09f0514',0),('76fb9708a3ee11eaad61005056b853d4','255207c9332e4dc98cec489efdbc9287',0),('76fb9708a3ee11eaad61005056b853d4','261e4f84e39c4d62a004142fac2cb7ca',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3a0',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3a1',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3a2',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3a3',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3a4',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b0',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b1',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b2',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b3',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b4',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b5',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3b6',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3c0',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3c1',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3c2',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3c3',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3c4',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3c5',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3d1',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3d2',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3d3',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3d4',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3e0',0),('76fb9708a3ee11eaad61005056b853d4','2ed1198871ff4a65b47121cb9835c3e1',0),('76fb9708a3ee11eaad61005056b853d4','36038a2d88ef4dca8eb447b65a118162',0),('76fb9708a3ee11eaad61005056b853d4','495fb637b46111eaad61005056b853d4',0),('76fb9708a3ee11eaad61005056b853d4','4acc230bf3ed4e54abc792e778c762ce',0),('76fb9708a3ee11eaad61005056b853d4','502a00f0471a42cb92ec5e07c7a992f9',0),('76fb9708a3ee11eaad61005056b853d4','5049012ab46111eaad61005056b853d4',0),('76fb9708a3ee11eaad61005056b853d4','566d0b302acd4a8ab56865006fd6a3ce',0),('76fb9708a3ee11eaad61005056b853d4','57080094350a49e7b35d75f3b7cc7c42',0),('76fb9708a3ee11eaad61005056b853d4','5b088ed6338f43ab97219f3293ef09a2',0),('76fb9708a3ee11eaad61005056b853d4','5c40cdf80b144c639394663867da4fa2',0),('76fb9708a3ee11eaad61005056b853d4','5fae9bf29f4f42c1ae5bc99a9302b586',0),('76fb9708a3ee11eaad61005056b853d4','6ca1474532ed4bfebc2f32426443f69b',0),('76fb9708a3ee11eaad61005056b853d4','73bad8e237ad40a6acceff5ba6590cd2',0),('76fb9708a3ee11eaad61005056b853d4','7f6090b2da0d4ee298cb61148deb9cff',0),('76fb9708a3ee11eaad61005056b853d4','8f71bc7250be4d169bf80574088f3b86',0),('76fb9708a3ee11eaad61005056b853d4','a6fc9673009e4605a74098ce40204e7e',0),('76fb9708a3ee11eaad61005056b853d4','b57ee356e95e47329ae59bf18dba8c80',0),('76fb9708a3ee11eaad61005056b853d4','b98edca6a7ff4af4a93a56f7ed8ea6e8',0),('76fb9708a3ee11eaad61005056b853d4','bc052c540b214c7b9b30d1f2d1def642',0),('76fb9708a3ee11eaad61005056b853d4','bff10e36dc5a46c39c07745c96db02d3',0),('76fb9708a3ee11eaad61005056b853d4','c609da8994e34edb9db156c9e220395a',0),('76fb9708a3ee11eaad61005056b853d4','ce9e0130f07a46a9b92620263d116eb6',0),('76fb9708a3ee11eaad61005056b853d4','d9df10c0b55441f481877968f322a250',0),('76fb9708a3ee11eaad61005056b853d4','deb80bf096344b178833bbae868b01a4',0),('76fb9708a3ee11eaad61005056b853d4','e7be59ee511c4fe0b56e8c2e1aab45aa',0),('76fb9708a3ee11eaad61005056b853d4','ed837adadaca47a682054ec0d89c8822',0),('76fb9708a3ee11eaad61005056b853d4','f45ae37715ce4124a46e3164bf0c2ac9',0),('76fb9708a3ee11eaad61005056b853d4','f9f72142dd344952bce7e77ac3db73c9',0);

/*Table structure for table `sys_user` */

DROP TABLE IF EXISTS `sys_user`;

CREATE TABLE `sys_user` (
  `id` varchar(32) NOT NULL COMMENT '主键.',
  `username` varchar(100) DEFAULT NULL COMMENT '用户名.',
  `display_name` varchar(30) DEFAULT NULL COMMENT '姓名.',
  `password` varchar(78) DEFAULT NULL COMMENT '密码.',
  `salt` varchar(32) DEFAULT NULL COMMENT '加密密码的盐.',
  `user_type` tinyint(1) NOT NULL DEFAULT '3' COMMENT '用户类别, 0: 酒店用户 1：拓邦用户 默认0',
  `linkman` varchar(30) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '电子邮箱.',
  `status` int(11) DEFAULT NULL COMMENT '状态, 0-正常 1-停用',
  `create_by` varchar(32) DEFAULT NULL COMMENT '创建人ID.',
  `update_by` varchar(32) DEFAULT NULL COMMENT '修改人ID.',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间.',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注.',
  `has_force` int(1) DEFAULT '0' COMMENT '登录互踢 0不互踢，1互踢',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标志 0正常，1删除',
  PRIMARY KEY (`id`),
  KEY `user_name` (`username`),
  KEY `user_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表.';

/*Data for the table `sys_user` */

insert  into `sys_user`(`id`,`username`,`display_name`,`password`,`salt`,`user_type`,`linkman`,`phone`,`email`,`status`,`create_by`,`update_by`,`create_time`,`update_time`,`remark`,`has_force`,`del_flag`) values ('68c79fda06bd42fbb80707d6c62498ea','13670036946',NULL,'ADn1s0iArGkpfo9EQcZwQcSeKbNWO/DOTUHxT7YLSUDApIdlYsLj2HOZvv4fflnKSA==','39F5B34880AC69297E8F4441C67041C4',0,NULL,'13670036946','125@qq.com',0,'e467744794694ee8a3e54f33e1334ef0','e467744794694ee8a3e54f33e1334ef0','2020-06-17 17:10:09','2020-06-17 17:10:09','topband',0,0);

/*Table structure for table `sys_user_hotel` */

DROP TABLE IF EXISTS `sys_user_hotel`;

CREATE TABLE `sys_user_hotel` (
  `user_id` varchar(32) NOT NULL COMMENT '来自sys_user表的id字段.',
  `hotel_id` varchar(32) NOT NULL COMMENT '来自h_hotel表的hotel_id字段.',
  `del_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  PRIMARY KEY (`user_id`,`hotel_id`),
  KEY `user_id` (`user_id`),
  KEY `hotel_id` (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='酒店管理员和酒店关系表.';

/*Data for the table `sys_user_hotel` */

/*Table structure for table `sys_user_role` */

DROP TABLE IF EXISTS `sys_user_role`;

CREATE TABLE `sys_user_role` (
  `user_id` varchar(32) NOT NULL COMMENT '来自sys_user表的id字段.',
  `role_id` varchar(32) NOT NULL COMMENT '来自sys_role表的id字段.',
  `del_flag` tinyint(1) DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_id` (`user_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关系表.';

/*Data for the table `sys_user_role` */

insert  into `sys_user_role`(`user_id`,`role_id`,`del_flag`) values ('68c79fda06bd42fbb80707d6c62498ea','76fb9708a3ee11eaad61005056b853d4',0);

/*Table structure for table `t_district` */

DROP TABLE IF EXISTS `t_district`;

CREATE TABLE `t_district` (
  `id` int(11) NOT NULL,
  `name` varchar(270) DEFAULT NULL COMMENT '名称.',
  `parent_id` int(11) DEFAULT NULL COMMENT '父 ID.',
  `initial` varchar(10) DEFAULT NULL COMMENT '拼音.',
  `initials` varchar(30) DEFAULT NULL COMMENT '拼音首字母.',
  `pinyin` varchar(600) DEFAULT NULL COMMENT '拼音首字母集合.',
  `extra` varchar(60) DEFAULT NULL COMMENT '附加说明.',
  `suffix` varchar(15) DEFAULT NULL COMMENT '行政级别.',
  `code` varchar(30) DEFAULT NULL COMMENT '行政代码.',
  `area_code` varchar(30) DEFAULT NULL COMMENT '区号.',
  `order` tinyint(3) DEFAULT NULL COMMENT '排序.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='中国各省/自治区/直辖市、市/自治州/盟/地区、区/县/县级市/旗数据表.';

/*Data for the table `t_district` */

/*Table structure for table `t_hotel_dictionary` */

DROP TABLE IF EXISTS `t_hotel_dictionary`;

CREATE TABLE `t_hotel_dictionary` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `style_sort` int(1) NOT NULL COMMENT '风格排序',
  `room_style` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '风格',
  `type_sort` int(1) NOT NULL COMMENT '房型排序',
  `type_name` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '房型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/*Data for the table `t_hotel_dictionary` */

/*Table structure for table `t_opt_log` */

DROP TABLE IF EXISTS `t_opt_log`;

CREATE TABLE `t_opt_log` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `user_id` varchar(32) DEFAULT NULL COMMENT '操作用户ID',
  `user_name` varchar(32) DEFAULT NULL COMMENT '用户名',
  `role_name` varchar(20) DEFAULT NULL COMMENT '角色名',
  `content` varchar(100) DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL COMMENT 'ip地址',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `del_flag` int(11) DEFAULT '0' COMMENT '删除标志，0：表示正常使用的数据 1：表示已删除的数据',
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';

/*Data for the table `t_opt_log` */

/*Table structure for table `u_linkman` */

DROP TABLE IF EXISTS `u_linkman`;

CREATE TABLE `u_linkman` (
  `id` varchar(32) NOT NULL COMMENT '主键.',
  `member_id` varchar(32) DEFAULT NULL COMMENT '会员ID',
  `link_man` varchar(20) DEFAULT NULL COMMENT '联系人',
  `link_phone` varchar(64) DEFAULT '0' COMMENT '联系人电话',
  `id_card` varchar(64) DEFAULT NULL COMMENT '身份证号',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间.',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标志, 0: 表示正常使用的数据, 1: 表示已删除的数据.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='联系人信息表';

/*Data for the table `u_linkman` */

/*Table structure for table `u_member` */

DROP TABLE IF EXISTS `u_member`;

CREATE TABLE `u_member` (
  `id` varchar(32) NOT NULL COMMENT '主键.会员编号',
  `name` varchar(64) DEFAULT NULL COMMENT '会员名.',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `openid` varchar(32) DEFAULT NULL COMMENT '微信返回用户唯一标识',
  `session_key` varchar(32) DEFAULT NULL COMMENT '微信返回会话密钥',
  `unionid` varchar(32) DEFAULT NULL COMMENT '微信返回用户在开放平台的唯一标识',
  `avatar_url` varchar(200) DEFAULT NULL COMMENT '头像',
  `status` int(11) DEFAULT '0' COMMENT '状态, 0-正常 1-锁定 2-已删除',
  `create_by` varchar(32) DEFAULT NULL COMMENT '创建人ID.',
  `update_by` varchar(32) DEFAULT NULL COMMENT '修改人ID.',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间.',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `del_flag` smallint(1) DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机号用户表';

/*Data for the table `u_member` */

/*Table structure for table `u_member_collect_hotel` */

DROP TABLE IF EXISTS `u_member_collect_hotel`;

CREATE TABLE `u_member_collect_hotel` (
  `member_id` varchar(32) NOT NULL COMMENT 'u_member表id',
  `hotel_id` varchar(32) NOT NULL COMMENT 'h_hotel表id',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间.',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间.',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标志, 0:正常使用, 1:删除',
  PRIMARY KEY (`member_id`,`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员收藏酒店表';

/*Data for the table `u_member_collect_hotel` */

/*Table structure for table `w_website_banner_image` */

DROP TABLE IF EXISTS `w_website_banner_image`;

CREATE TABLE `w_website_banner_image` (
  `id` varchar(32) NOT NULL COMMENT '照片id',
  `image_path` varchar(200) DEFAULT NULL COMMENT '上传云端的相对路径',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0未上架，1上架',
  `create_by` varchar(32) DEFAULT NULL COMMENT '创建人',
  `update_by` varchar(32) DEFAULT NULL COMMENT '更新人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `del_flag` int(1) NOT NULL DEFAULT '0' COMMENT '0-正常，1-已删除',
  `sort` int(3) NOT NULL DEFAULT '1' COMMENT '图片序号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='官网轮播图片';


/*Table structure for table `w_website_news` */

DROP TABLE IF EXISTS `w_website_news`;

CREATE TABLE `w_website_news` (
  `id` varchar(32) NOT NULL COMMENT '照片id',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `subtitle` varchar(100) DEFAULT NULL COMMENT '副文本',
  `image_path` varchar(200) DEFAULT NULL COMMENT '封面图片相对路径',
  `content` text COMMENT '内容',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0未上架，1上架',
  `create_by` varchar(32) DEFAULT NULL COMMENT '创建人',
  `update_by` varchar(32) DEFAULT NULL COMMENT '修改人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `del_flag` int(1) NOT NULL DEFAULT '0' COMMENT '0-正常，1-已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='酒店图片.';

/* Function  structure for function  `escape_str` */

/*!50003 DROP FUNCTION IF EXISTS `escape_str` */;
DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` FUNCTION `escape_str`(input TEXT) RETURNS text CHARSET utf8mb4
BEGIN
      DECLARE sTemp TEXT;
      select REPLACE(input, '%', '\%') into sTemp from dual;
      SELECT REPLACE(sTemp, '_', '\_') INTO sTemp FROM DUAL;
      RETURN sTemp;
    END */$$
DELIMITER ;

INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('1','1','标准','1','套房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('2','2','豪华','2','房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('3','3','高级','3','单人房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('4','4','尊贵','4','双人房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('5','5','商务','5','三人房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('6','6','总统','6','四人房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('7','7','休闲','7','家庭房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('8','8','情侣','8','别墅');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('9','9','舒适','9','公寓房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('10','10','浪漫','10','木屋');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('11','11','时尚','11','房车');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('12','12','海景','12','帐篷');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('13','13','湖景','13','和室');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('14','14','河景','14','和洋房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('15','15','山景','15','圆床房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('16','16','城景','16','水床房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('17','17','园景','17','胶囊房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('18','18','中式','18','暖炕房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('19','19','欧式','19','宿舍房');
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('20','20','韩式','0',NULL);
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('21','21','日式','0',NULL);
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('22','22','法式','0',NULL);
INSERT INTO `t_hotel_dictionary` (`id`, `style_sort`, `room_style`, `type_sort`, `type_name`) VALUES('23','23','复式','0',NULL);



