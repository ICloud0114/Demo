var Moment = require("../../utils/moment.js");
var DATE_LIST = [];
var DATE_YEAR = new Date().getFullYear()
var DATE_MONTH = new Date().getMonth() + 1
var DATE_DAY = new Date().getDate()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    checkInDate: Moment(new Date()).format('YYYY-MM-DD'),
    checkOutDate: Moment(new Date()).add(1, 'day').format('YYYY-MM-DD')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //设缓存缓存起来的日期
    // wx.setStorage({
    //   key: 'ROOM_SOURCE_DATE',
    //   data: {
    //     checkInDate: Moment(new Date()).format('YYYY-MM-DD'),
    //     checkOutDate: Moment(new Date()).add(1, 'day').format('YYYY-MM-DD')
    //   }
    // });
    
  },
  showCalender:function(){
    wx.navigateTo({
      url: '/pages/calendar/index?inDate=' + this.data.checkInDate +'&outDate='+ this.data.checkOutDate
    })
  }


})