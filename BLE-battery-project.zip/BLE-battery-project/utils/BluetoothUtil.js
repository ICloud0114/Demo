var StringUtil = require('StringUtil');
const TIME_LIMIT = 30
var seartchBleDeviceLimit = TIME_LIMIT
var retryConnectTime = 0
var msgRecieveCallback //蓝牙数据返回回调
var bleStatusCallback //蓝牙连接回调
const SERVICE_UUIDS = ['FFE0']
// 0XFFE0
// const SERVICE_UUIDS = ['0000FFF0-0000-1000-8000-00805F9B34FB','0000FFB0-0000-1000-8000-00805F9B34FB']
var tempData = []
var deviceTimer
/**
 * 打开蓝牙适配器
 */
function openBluetoothAdapter(callBack) {
  onConnectStatusChange()
  wx.openBluetoothAdapter({
    success: function(res) {
      console.log('开启蓝牙', 'openBluetoothAdapter-->success:' + JSON.stringify(res))
      console.log('开启蓝牙', 'SERVICE_UUIDS-->' + JSON.stringify(SERVICE_UUIDS))
      startBluetoothDevicesDiscovery(callBack)
    },
    fail: function(res) {
      console.log('开启蓝牙', 'openBluetoothAdapter-->fail' + JSON.stringify(res))
      //当前蓝牙适配器不可用
      if (res.errCode =='10001'){
        var errorCode = res.errCode
        if (res.state == 3){
          errorCode = '10001-3'//3:手机微信的蓝牙权限未开， 4: 手机蓝牙未开
        }
        if (callBack){
            callBack(errorCode)
        }
      }else{
        if (callBack) {
          retry(callBack, -1)
        }
      }
    }
  })
}

/**
 * 扫描附近的蓝牙设备
 */
function startBluetoothDevicesDiscovery(callBack) {
  wx.startBluetoothDevicesDiscovery({
    services: SERVICE_UUIDS,
    allowDuplicatesKey: true,
    success: function(res) {
      if (res.errCode == 0) {
        console.log('扫描', 'startBluetoothDevicesDiscovery-->success:' + JSON.stringify(res))
        getBlueDevices(callBack)
      } else {
        console.log('扫描', 'startBluetoothDevicesDiscovery-->err:' + JSON.stringify(res))
        if (callBack) {
          retry(callBack, -1)
        }
      }
    },
    fail: function(res) {
      console.log('扫描', 'startBluetoothDevicesDiscovery-->fail' + JSON.stringify(res))
      if (callBack) {
        retry(callBack, -2)
      }
    },
  })

}

/**
 * 获取所有蓝牙设备
 */
function getBlueDevices(callBack) {
  console.log("获取已扫描到的蓝牙设备")
  deviceTimer = setTimeout(function() {
    console.log("timer------>" + seartchBleDeviceLimit)
    wx.getBluetoothDevices({
      success: function(res) {
        console.log("devices------>" + res.devices)
        var devices = filterBleDevices(res.devices)
        if (devices.length == 0) {
          retry(callBack, -3)
        } else {
          seartchBleDeviceLimit = TIME_LIMIT
          if (callBack) {
            callBack(devices)
          }
          getBlueDevices(callBack)
          clearTimer()
        }
      },
      fail: function(res) {
        console.log('蓝牙搜索失败-->' + JSON.stringify(res))
        console.log("limit Time --> " + seartchBleDeviceLimit)
        retry(callBack, -4)
        console.log('getBlueDevices-->fail')
      },
    })
  }, 1000)
}
/**
 * 过滤蓝牙设备
 */
function filterBleDevices(devices) {
  var filters = []
  for (var i = 0; i < devices.length; i++) {
    console.log('localName--->' + devices[i].localName)
    console.log('name--->' + devices[i].name)
    console.log('rssi--->' + devices[i].RSSI)
    console.log('services-uuid -->' + devices[i].SERVICE_UUIDS)
    if (devices[i].RSSI != 0) {
      console.log('蓝牙--->' + devices[i].localName)
      if (devices[i].advertisData && devices[i].advertisData.byteLength) {
        var firstByte
        var secondByte
        for (var j = 0; j < devices[i].advertisData.byteLength; j++) {
          var viewData = new DataView(devices[i].advertisData)

          if (j == 0) {
            firstByte = viewData.getInt8(j)
          }
          if (j == 1) {
            secondByte = viewData.getInt8(j)
            break
          }
        }
        // console.log('advertisData---TB--' + firstByte +'--' + secondByte)
        if (firstByte == 0 && secondByte == 0) {
          console.log('advertisData---localName--' + devices[i].localName)
          console.log('advertisData---name--' + devices[i].name)
          if (devices[i].localName != undefined){
            filters.push(devices[i])
          }else if(devices[i].name != undefined){
            devices[i].localName = devices[i].name
            filters.push(devices[i])
          }
        }
      }
    }
  }
  return filters
}

function clearTimer(){
  console.log("清空定时")
  if (deviceTimer){
    clearTimeout(deviceTimer)
    seartchBleDeviceLimit = 0
    console.log("timer: -> " + deviceTimer)
  }
}
//尝试重新扫描
function retry(callBack, err) {
  if (seartchBleDeviceLimit > 0) {
    if (callBack) {
      seartchBleDeviceLimit--
      console.log('尝试重新扫描-->' + seartchBleDeviceLimit)
      startBluetoothDevicesDiscovery(callBack)
      // setTimeout(function() {
      //重新扫描蓝牙
      // wx.stopBluetoothDevicesDiscovery({
      //   success: function(res) {

      //   },
      //   fail: function(res) {
      //     retry(callBack, err)
      //   }
      // })
      // }, 1000)
    }
  } else {
    if (callBack) {
      var limit = 10 - seartchBleDeviceLimit
      callBack(err - limit)
      seartchBleDeviceLimit = TIME_LIMIT
      console.log("seartchBleDeviceLimit-->" + seartchBleDeviceLimit)
      //扫描蓝牙超时，停止扫描
      wx.stopBluetoothDevicesDiscovery({
        success: function(res) {
          console.log('扫描蓝牙超时，停止扫描-->')
        },
      })
    }
  }
}


/**
 * 连接蓝牙
 */
function connectBle(deviceId, timeout, callBack) {
  console.log("蓝牙连接-->" + new Date().getTime())
  wx.createBLEConnection({
    deviceId: deviceId,
    timeout: timeout,
    success: function(res) {
      retryConnectTime = 0
      wx.stopBluetoothDevicesDiscovery({
        success: function(res) {},
      })
      // getApp().data.serialBle = 0
      console.log("连接成功-->" + JSON.stringify(res))
      getBLEDeviceServices(deviceId, callBack)
    },
    fail: function(res) {
      console.log("连接失败-->" + JSON.stringify(res))
      if (retryConnectTime < 2) {
        setTimeout(function() {
          connectBle(deviceId, timeout, callBack)
          retryConnectTime++
          console.log("连接重试retryConnectTime-->" + retryConnectTime)
        }, 100)
      } else if (callBack) {
        retryConnectTime = 0
        callBack(-5)
      }
    },
  })
}

/**
 * 获取蓝牙服务列表
 */
function getBLEDeviceServices(deviceId, callBack) {
  wx.getBLEDeviceServices({
    deviceId: deviceId,
    success: function(res) {
      for (var index in res.services) {
        console.log("getBLEDeviceServices", "res.services[index].uuid-->" + res.services[index].uuid)
        if (res.services[index].uuid == '0000FFE5-0000-1000-8000-00805F9B34FB') {
          getBLEDeviceCharacteristics(deviceId, res.services[index].uuid, callBack);
        } else if (res.services[index].uuid == '0000FFE0-0000-1000-8000-00805F9B34FB') {
          getBLEDeviceCharacteristics(deviceId, res.services[index].uuid, callBack);
        }
      }
    },
    fail: function(res) {
      if (callBack) {
        callBack(-7)
      }
    },
  })
}

/**
 * 设置蓝牙接收数据监听
 */
function setMsgRecieveCallback(callBack) {
  msgRecieveCallback = callBack
}

/**设置蓝牙连接状态监听 */
function setBleConnectCallBack(callBack){
  bleStatusCallback = callBack
  console.log("监听蓝牙连接回调")
}

/**
 * 获取蓝牙设备某个服务中的所有 characteristic（特征值）
 */
function getBLEDeviceCharacteristics(deviceId, serviceId, callBack) {
  console.log("获取蓝牙设备某个服务中的所有 characteristic（特征值）")
  wx.getBLEDeviceCharacteristics({
    deviceId: deviceId,
    serviceId: serviceId,
    success: function(res) {
      var bleDevice = {}
      bleDevice.deviceId = deviceId;
      bleDevice.serviceId = serviceId;
      if (msgRecieveCallback) {
        for (var index in res.characteristics) {
          if (res.characteristics[index].properties.notify) {
            console.log("蓝牙特征 -- notify")
            var uuid = res.characteristics[index].uuid
            onMessageReceived(bleDevice.deviceId, bleDevice.serviceId, uuid)
            if (callBack) {
              callBack(bleDevice)
            }
          } else if (res.characteristics[index].properties.write) {
            // console.log("蓝牙特征 -- write")
            // var uuid = res.characteristics[index].uuid
            // bleDevice.uuid = uuid
            // setTimeout(function() {
            //   if (callBack) {
            //     callBack(bleDevice)
            //   }
            //   console.log("getBLEDeviceCharacteristics", "bleDevice-->" + JSON.stringify(bleDevice))
            // }, 100)
          }
        }
      }
    },
    fail: function(res) {
      console.log("蓝牙特征获取失败")
      if (callBack) {
        callBack(-8)
      }
    }
  })
  wx.onBLECharacteristicValueChange(function(res) {


    var dataView = new DataView(res.value)
    for (var i = 0; i < res.value.byteLength; i++) {
      if(dataView.getUint8(i) == 94){
        tempData = []
        tempData.push(dataView.getUint8(i))
        // console.log('start-->')
      }else if(tempData.length > 0){
        tempData.push(dataView.getUint8(i))
        if (tempData.length >= 121){
          break
        }
      }
    }
    // console.log('start-->' + tempData.length)

////////////// 1 + 112 + 1 
    if ([tempData[0] == 94] && tempData.length >= 121 ){

      if (tempData[120] == 0){
        console.log('接收蓝牙数据-->' + tempData[120])
        console.log('接收蓝牙数据-->' + tempData)
        let result = checkReceiveData(tempData)
        tempData = []
        if (result != undefined && msgRecieveCallback){
          msgRecieveCallback(result)
        }
        
      }else{
        console.log('接收蓝牙数据-->' + tempData[120])
        tempData = []
      }
      console.log('接收蓝牙数据-->' + tempData.length)
    }
  })
}

function checkReceiveData(dataArray){

  // Head 0x5e
  let check_voltage = checkValue(dataArray,1,8)//8
  let check_current = checkValue(dataArray,9,8)
  let check_fcc = checkValue(dataArray,17,8)
  let check_cycle = checkValue(dataArray,25,4)
  let check_soc = checkValue(dataArray,29,4)
  let check_temperature = checkValue(dataArray,33,4)
  let check_battery_status = checkValue(dataArray,37,4)
  let check_afe_status = checkValue(dataArray,41,4)
  var check_valtages = 0
  for (var i = 0; i < 16; i++){
    check_valtages += checkValue(dataArray,(45 + i * 4), 4)
  }
  // end 0x00
  let sum1 = checkValue(dataArray,109,2)
  let sum2 = checkValue(dataArray,111,2)

  let all_check = check_voltage + check_current + check_fcc + check_cycle + check_soc + check_temperature + check_battery_status + check_afe_status + check_valtages
  console.log('all_check-->' + all_check)

  var check_sum = '0x' + Number(sum1).toString(16) + Number(sum2).toString(16)

  console.log('check_Sum-->' + Number(check_sum))

  if (all_check == check_sum){
    console.log('校验成功')
    let d_voltage = calculateRealValue(dataArray,1,8)
    let d_current = calculateRealValue(dataArray,9,8)
    let d_fcc = calculateRealValue(dataArray,17,8)
    let d_cycle = calculateRealValue(dataArray,25,4)
    let d_soc = calculateRealValue(dataArray,29,4)
    let d_temperature = calculateRealValue(dataArray,33,4)
    let d_battery_status = calculateRealValue(dataArray,37,2)
    let d_afe_status = calculateRealValue(dataArray,41,2)
    var d_valtages = []
    for (var i = 0; i < 16; i++){
      let sub = calculateRealValue(dataArray,(45 + i * 4), 4)
      if(sub != 0){
        d_valtages.push(Number(sub))
      }
    }
    // console.log('d_valtages-->' + d_valtages)
    console.log('电流-->' + d_current)
    var receiveData = []
    receiveData.voltage = (parse(d_voltage) / 1000.0).toFixed(1)
    receiveData.current = (parse(d_current) / 1000).toFixed(1)
    receiveData.fcc = (parse(d_fcc) / 1000.0).toFixed(1)
    receiveData.cycle = parse(d_cycle)
    receiveData.soc = parse(d_soc)
    if (d_temperature >= 2331){
      receiveData.temperature = ((parse(d_temperature) - 2371) / 10).toFixed(1)
    }else{
      receiveData.temperature = -41
    }
    receiveData.battery_status = d_battery_status
    receiveData.afe_status = d_afe_status
    receiveData.valtages = d_valtages
    return receiveData//[d_voltage, d_current, d_fcc, d_cycle, d_soc, d_temperature, d_battery_status, d_afe_status, d_valtages]
  }else{
    return undefined
  }
}
//校验和
function checkValue(buffer, index, length){
  var check = 0x00
    for(var i = 0; i < length / 2; i ++){
      let a = translateToAscii(buffer[index + i * 2])
      let b = translateToAscii(buffer[index + i * 2 + 1])
      let num = Number('0x' + a + b)
      check += num
    }
    // console.log('check --> ' + check)
    return check
}
///十进制转Ascci
function translateToAscii(num){
  if (num >= 48 && num <= 57){
    return Number(num - 48).toString(16)
  }else if(num >= 65 && num <= 70){
    return Number(num - 65 + 10).toString(16)
  }else{
    return 0
  }
}
///Ascci 转十六进制
function calculateRealValue(buffer, index, length){
  let result ='0x'
  // 1-9
  for(var i = 0; i < length / 2; i ++){
    let a = translateToAscii(buffer[index + length - i * 2 - 2])
    let b = translateToAscii(buffer[index + length - i * 2 - 1])
    result += (a + b)
  }
  console.log('calculate --> ' + result)
  return result
}
///十六进制转十进制
function parse(hex) {
  hex= parseInt(hex, 16);
  hex= hex| 0xFFFFFFFF00000000;
  return hex;
}

function onMessageReceived(deviceId, serviceId, uuid) {
  wx.notifyBLECharacteristicValueChange({
    deviceId: deviceId,
    serviceId: serviceId,
    characteristicId: uuid,
    state: true,
    success: function(res) {
      console.log("notifyBLECharacteristicValueChange", "调用成功！")
    },
    fail: function(res) {
      console.log("notifyBLECharacteristicValueChange", "调用失败！")
    }
  })
}


function connectFirstBleDevice(connectCallback) {
  openBluetoothAdapter(function(devices) {
    if (devices < 0) {
      // 没有搜索到设备
      if (connectCallback) {
        connectCallback(devices)
      }
    } else {
      connectBle(devices[0].deviceId, 10000, function(bleDevice) {
        if (connectCallback) {
          connectCallback(bleDevice)
        }
      })
    }
  })
}

/**
 * 关闭蓝牙
 * callBack 暂时没有用到
 */
function closeBluetoothAdapter(callBack) {
  console.log("timer ====" + seartchBleDeviceLimit)
  wx.closeBluetoothAdapter({
    success: function(res) {
      console.log("closeBluetoothAdapter调用成功" + JSON.stringify(res))
      console.log("关闭蓝牙")
      if (callBack) {
        callBack(0)
      }
    },
    fail: function(res) {
      console.log("BluetoothUtil", "closeBluetoothAdapter 调用失败" + JSON.stringify(res))
      if (callBack) {
        callBack(1)
      }
    }
  })
}

function closeCurrentConnect(deviceId, callBack) {
  wx.closeBLEConnection({
    deviceId: deviceId,
    success: function(res) {
      closeBluetoothAdapter(callBack)
      console.log("closeCurrentConnect调用成功-->" + JSON.stringify(res))
      // if (callBack) {
      //   callBack(0)
      // }
    },
    fail: function(res) {
      closeBluetoothAdapter()
      console.log( "closeCurrentConnect调用失败-->" + JSON.stringify(res))
      if (callBack) {
        callBack(-1)
      }
    }
  })
}

function onConnectStatusChange() {
  wx.onBLEConnectionStateChange(function(res) {
    // 该方法回调中可以用于处理连接意外断开等异常情况
    console.log("onBLEConnectionStateChange-->" + JSON.stringify(res))
    bleStatusCallback(res)
  })
}

module.exports.openBluetoothAdapter = openBluetoothAdapter;
module.exports.connectBle = connectBle;
module.exports.onMessageReceived = onMessageReceived;
module.exports.connectFirstBleDevice = connectFirstBleDevice;
module.exports.setMsgRecieveCallback = setMsgRecieveCallback;
module.exports.closeBluetoothAdapter = closeBluetoothAdapter;
module.exports.closeCurrentConnect = closeCurrentConnect;
module.exports.clearTimer = clearTimer;
module.exports.setBleConnectCallBack = setBleConnectCallBack;