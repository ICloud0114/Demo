function drawCircle(canvasName, settingTemp) {
  const ctx = wx.createCanvasContext(canvasName, this)
  var circle = 110//wx.getSystemInfoSync().windowWidth * 0.5
  var rpx = 1//wx.getSystemInfoSync().windowWidth / 750
  var yCircle = 110//476 * rpx

  ctx.setGlobalAlpha(1)
  ctx.beginPath()
  ctx.arc(circle, yCircle, 100 * rpx, 0, 2 * Math.PI)
  ctx.setLineCap('round')
  ctx.setStrokeStyle('#F7F7F7')
  ctx.setLineWidth(5)
  ctx.stroke()

  let color = '#3c90fd'
  let progress = settingTemp / 100
  if (progress > 0) {
    // Draw arc
    ctx.beginPath()
    ctx.arc(circle, yCircle, 100 * rpx, - 0.5 * Math.PI, (2 * progress - 0.5) * Math.PI)
    ctx.setLineCap('round')
    ctx.setStrokeStyle(color)
    ctx.setLineWidth(5 * rpx)
    ctx.stroke()
  }

  var alpha = 0.4
  

  ctx.setFillStyle('#000000')

  ctx.setFontSize(40 * rpx)
  var text = "SOC"
  ctx.setGlobalAlpha(alpha)
  ctx.fillText(text, circle - ctx.measureText(text).width / 2, 110 *rpx)


  ctx.setFontSize(30 * rpx)
  text = (settingTemp).toString() + '%'
  let textWidth = ctx.measureText(text).width
  ctx.setGlobalAlpha(1)
  ctx.fillText(text, circle - textWidth / 2, 150 * rpx )

  ctx.draw()
}

module.exports.drawCircle = drawCircle;