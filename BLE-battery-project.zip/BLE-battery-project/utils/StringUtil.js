//十六进制字符串转字节数组

function hexStr2Bytes(str) {
  var pos = 0;

  var len = str.length;

  if (len % 2 != 0) {
    return null;
  }
  len /= 2;
  var hexA = new Array();
  for (var i = 0; i < len; i++) {
    var s = str.substr(pos, 2);
    var v = parseInt(s, 16);
    hexA.push(v);
    pos += 2;
  }

  return hexA;

}

//字节数组转十六进制字符串

function Bytes2HexStr(arr) {

  var str = "";
  console.log('StringUtil', arr)
  for (var i = 0; i < arr.length; i++) {
    var tmp;
    if (null != arr[i]) {
      if (arr[i] < 0) {
        tmp = (255 + arr[i] + 1).toString(16);
      } else {
        tmp = arr[i].toString(16);
      }
    }
    if (tmp.length == 1) {

      tmp = "0" + tmp;

    }

    str += tmp;

  }

  return str;

}

function byteToString(arr) {
  if (typeof arr === 'string') {
    return arr;
  }
  var str = '',
    _arr = arr;
  for (var i = 0; i < _arr.length; i++) {
    var one = _arr[i].toString(2),
      v = one.match(/^1+?(?=0)/);
    if (v && one.length == 8) {
      var bytesLength = v[0].length;
      var store = _arr[i].toString(2).slice(7 - bytesLength);
      for (var st = 1; st < bytesLength; st++) {
        store += _arr[st + i].toString(2).slice(2);
      }
      str += String.fromCharCode(parseInt(store, 2));
      i += bytesLength - 1;
    } else {
      str += String.fromCharCode(_arr[i]);
    }
  }
  return str;
}

function  stringToBytes ( str )  {    
  var bytes = new Array();
  var len, c;
  len = str.length;
  for (var i = 0; i < len; i++) {
    c = str.charCodeAt(i);
    if (c >= 0x010000 && c <= 0x10FFFF) {
      bytes.push(((c >> 18) & 0x07) | 0xF0);
      bytes.push(((c >> 12) & 0x3F) | 0x80);
      bytes.push(((c >> 6) & 0x3F) | 0x80);
      bytes.push((c & 0x3F) | 0x80);
    } else if (c >= 0x000800 && c <= 0x00FFFF) {
      bytes.push(((c >> 12) & 0x0F) | 0xE0);
      bytes.push(((c >> 6) & 0x3F) | 0x80);
      bytes.push((c & 0x3F) | 0x80);
    } else if (c >= 0x000080 && c <= 0x0007FF) {
      bytes.push(((c >> 6) & 0x1F) | 0xC0);
      bytes.push((c & 0x3F) | 0x80);
    } else {
      bytes.push(c & 0xFF);
    }
  }
  return bytes;

   
}  

/**
 * 字符串转16进制
 */
function strToHexCharCode(str) {　　
  if (str === "") {
    return "";　　
  }　
  // var hexCharCode = [];　　　
  // for (var i = 0; i < str.length; i++) {　　　　
  //   hexCharCode.push('0x'+(str.charCodeAt(i)).toString(16));　　
  // }　　
  return encodeUtf8(str);
}


//判断字符是否为空的方法
function isEmpty(obj) {
  if (typeof obj == "undefined" || obj == null || obj == "") {
    return true;
  } else {
    return false;
  }
}

/**
 * 将字符以utf-8编码
 */
function encodeUtf8(text) {
  const code = encodeURIComponent(text);
  const bytes = [];
  for (var i = 0; i < code.length; i++) {
    const c = code.charAt(i);
    if (c === '%') {
      const hex = code.charAt(i + 1) + code.charAt(i + 2);
      bytes.push('0x' +hex);
      i += 2;
    } else bytes.push('0x' + c.charCodeAt(0).toString(16));
  }
  return bytes;
}

module.exports.hexStr2Bytes = hexStr2Bytes;
module.exports.Bytes2HexStr = Bytes2HexStr;
module.exports.byteToString = byteToString;
module.exports.stringToBytes = stringToBytes ;
module.exports.isEmpty = isEmpty;
module.exports.strToHexCharCode = strToHexCharCode;
module.exports.encodeUtf8 = encodeUtf8;