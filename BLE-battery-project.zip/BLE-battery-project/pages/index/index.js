//index.js
//获取应用实例
const app = getApp()
var StringUtil = require("../../utils/StringUtil.js")
Component({
  properties: {

  },
  /**
   * 页面的初始数据
   */
  data: {

    destory:false,
    winHeight:"",//窗口高度
    currentTab:0, //预设当前项的值
    scrollLeft:0, //tab标题的滚动条位置

    selectedDevice:{},//上级页面传入的设备
    connectedDevice:{},//连接上的设备
    animation: '',

    temperature:30,     //电池温度
    cycleTimes:300,     //电池循环次数
    batteryStatus:'待机', //电池状态
    // healthStatus: '完美', //健康状态
    voltage: 13.2,  //电压
    batteryCapacity: 100,//容量
    current: 13.2, //电流
    soc: 75     //电池容量百分比
  },
  methods:{
    bindViewTap: function() {
      wx.navigateTo({
        url: '../logs/logs'
      })
    },
    onReady: function(){
      console.log()
    },
    onLoad: function () {
      
      this.popup = this.selectComponent("#userAuthorizeId");
      
      this.popup.showPopup()
      let arr = [94,
        54,55,50,66,48,48,48,48,
        67,48,49,68,70,69,70,70,
        48,52,56,55,48,49,48,48,
  
        48,48,48,48,
        48,48,48,48,
        49,66,48,57,
        50,48,50,48,
        50,48,50,48,
  
        68,68,48,53,
        68,69,48,53,
        68,70,48,53,
        69,48,48,53,
        69,49,48,53,
        69,50,48,53,
        69,51,48,53,
        69,52,48,53,
        69,53,48,53,
        69,54,48,53,
        69,55,48,53,
        69,56,48,53,
        69,57,48,53,
        69,65,48,53,
        69,66,48,53,
        69,67,48,53,
        49,51,51,52,
        0,0,0,0,0,0,0,0]
  
      // this.checkReceiveData(arr)
    },
      //取消事件
    _error() {
      console.log('你点击了取消');
      this.popup.hidePopup();
    },
    //确认事件
    _success() {
      console.log('你点击了确定');
      this.popup.hidePopup();
    },
    startSearch(){
      // wx.redirectTo({
      //   url: '../bluetoothList/list',
      // })
      this.popup.showPopup()
    },
  
    checkReceiveData:function (dataArray){
  
      // Head 0x5e
      let check_voltage = this.checkValue(dataArray,1,8)//8
      let check_current = this.checkValue(dataArray,9,8)
      let check_fcc = this.checkValue(dataArray,17,8)
      let check_cycle = this.checkValue(dataArray,25,4)
      let check_soc = this.checkValue(dataArray,29,4)
      let check_temperature = this.checkValue(dataArray,33,4)
      let check_battery_status = this.checkValue(dataArray,37,4)
      let check_afe_status = this.checkValue(dataArray,41,4)
      var check_valtages = 0
      for (var i = 0; i < 16; i++){
        check_valtages += this.checkValue(dataArray,(45 + i * 4), 4)
      }
      // end 0x00
      let sum1 = this.checkValue(dataArray,109,2)
      let sum2 = this.checkValue(dataArray,111,2)
    
      let all_check = check_voltage + check_current + check_fcc + check_cycle + check_soc + check_temperature + check_battery_status + check_afe_status + check_valtages
      console.log('all_check-->' + all_check)
  
      var check_sum = '0x' + Number(sum1).toString(16) + Number(sum2).toString(16)
    
      console.log('check_Sum-->' + Number(check_sum))
  
      if (all_check == check_sum){
        console.log('校验成功')
        let d_voltage = this.calculateRealValue(dataArray,1,8)
        let d_current = this.calculateRealValue(dataArray,9,8)
        let d_fcc = this.calculateRealValue(dataArray,17,8)
        let d_cycle = this.calculateRealValue(dataArray,25,4)
        let d_soc = this.calculateRealValue(dataArray,29,4)
        let d_temperature = this.calculateRealValue(dataArray,33,4)
        let d_battery_status = this.calculateRealValue(dataArray,37,2)
        let d_afe_status = this.calculateRealValue(dataArray,41,2)
        var d_valtages = []
        for (var i = 0; i < 16; i++){
          let sub = this.calculateRealValue(dataArray,(45 + i * 4), 4)
          if(sub != 0){
            d_valtages.push(Number(sub))
          }
        }
        // console.log('d_valtages-->' + d_valtages)
        console.log('电流-->' + this.parse(d_current))
      }
    },
    
    checkValue: function(buffer, index, length){
      var check = 0x00
      for(var i = 0; i < length / 2; i ++){
        let a = this.tarnslateToAscii(buffer[index + i * 2])
        let b = this.tarnslateToAscii(buffer[index + i * 2 + 1])
        let num = Number('0x' + a + b)
        check += num
      }
      // console.log('check --> ' + check)
      return check
    },
  
    calculateRealValue: function(buffer, index, length){
      let result ='0x'
      // 1-9
      for(var i = 0; i < length / 2; i ++){
  
        let a = this.tarnslateToAscii(buffer[index + length - i * 2 - 2])
        let b = this.tarnslateToAscii(buffer[index + length - i * 2 - 1])
        
        result += (a + b)
      }
      console.log('calculate --> ' + Number(result))
      console.log('parse --> ' + this.parse(result))
      return result
    },
    
    tarnslateToAscii: function(num){
      if (num >= 48 && num <= 57){
        return Number(num - 48).toString(16)
      }else if(num >= 65 && num <= 70){
        return Number(num - 65 + 10).toString(16)
      }else{
        return 0
      }
    },
  
    parse: function(hex) {
      hex= parseInt(hex, 16);
      hex= hex| 0xFFFFFFFF00000000;
      return hex;
    }
  },
  pageLifetimes: {
    show() {
      if (typeof this.getTabBar === 'function' &&
        this.getTabBar()) {
        this.getTabBar().setData({
          selected: 0
        })
      }
    }
  }
})
