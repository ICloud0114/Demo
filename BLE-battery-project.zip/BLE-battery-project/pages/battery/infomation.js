// pages/battery/infomation.js
var Ble = require("../../utils/BluetoothUtil.js")
var canvas = require("../../utils/CanvasUtil.js")

var _animation;
Component({

  properties: {

  },
  /**
   * 页面的初始数据
   */
  data: {

    destory:false,
    winHeight:"",//窗口高度
    currentTab:0, //预设当前项的值
    scrollLeft:0, //tab标题的滚动条位置

    selectedDevice:{},//上级页面传入的设备
    connectedDevice:{},//连接上的设备
    animation: '',

    temperature:30,     //电池温度
    cycleTimes:300,     //电池循环次数
    batteryStatus:'待机', //电池状态
    // healthStatus: '完美', //健康状态
    voltage: 13.2,  //电压
    batteryCapacity: 100,//容量
    current: 13.2, //电流
    soc: 75     //电池容量百分比
  },
  methods:{
     /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      this.data.selectedDevice = JSON.parse(options.device) 
      this.connectBlueTooth()
      var that = this; 
    //  高度自适应
      wx.getSystemInfo( {  
        success: function( res ) {  
          var clientHeight = res.windowHeight,
              clientWidth = res.windowWidth,
              rpxR = 750 / clientWidth;
          var calc = clientHeight * rpxR - 80;
            console.log(calc)
          that.setData( {  
            winHeight: calc  
          });  
        }  
      });

      _animation = wx.createAnimation({
        duration: 1,
        timingFunction: 'linear', // "linear","ease","ease-in","ease-in-out","ease-out","step-start","step-end"
        delay: 0,
        transformOrigin: '50% 50% 0'
      })

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
      canvas.drawCircle("canvasProgressbg",this.data.soc)
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
      this.data.destory = true
      var deviceId = this.data.selectedDevice.deviceId
      console.log('closeCurrentBleConnect-->' + deviceId)
      if (deviceId) {
        Ble.closeCurrentConnect(deviceId, callBack)
      }
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

    // 滚动切换标签样式
    switchTab:function(e){
      this.setData({
          currentTab:e.detail.current
      });
      this.checkCor();
    },
    // 点击标题切换当前页时改变样式
    swichNav:function(e){
      var cur = e.target.dataset.current;
      if(this.data.currentTaB==cur){return false;}
      else{
        this.setData({
            currentTab:cur
        })
      }
    },
    //判断当前滚动超过一屏时，设置tab标题滚动条。
    checkCor:function(){
      if (this.data.currentTab>4){
        this.setData({
          scrollLeft:300
        })
      }else{
        this.setData({
          scrollLeft:0
        })
      }
    },
    /**连接蓝牙 */
    connectBlueTooth(){
      var that = this
      var deviceId = that.data.selectedDevice.deviceId
      console.log('蓝牙信息-->' + that.data.selectedDevice.localName)
      if (deviceId) {
        Ble.connectBle(deviceId, 10000, function (bleDevice) {
          if (bleDevice == undefined | bleDevice.deviceId == undefined) {
            console.log('连接蓝牙出错')
            // that.resetFail(-1, '连接蓝牙失败！')
          } else {
            console.log('连接蓝牙成功！')
            that.data.connectedDevice = bleDevice
            // that.data.connectedDevice.localName = that.data.selectedDevice.localName 
          }
        })
        this.blueToothConnectedStatus()
        this.blueToothCallback()
      }
    },
    /**监听蓝牙连接状态 */
    blueToothConnectedStatus(){
      var that = this
      Ble.setBleConnectCallBack(function(res){
        if (res.connected){
          that.connectedId = res.deviceId
        }else if(that.connectedId == res.deviceId && that.status < 2){
          wx.showModal({
            title: '',
            content: '蓝牙已断开，请重新连接',
            showCancel: false,
            confirmText: '好的！',
            success: function(res) {
              wx.navigateBack({
                detal: 1
              })
            }
          })
        }
      })
    },
    /**接受蓝牙消息回调 */
    blueToothCallback(){
      var that = this
      Ble.setMsgRecieveCallback(function(res){
        if (that.data.destory) {
          console.log("---destory")
          return;
        }
        // clearTimeout(that.data.timeOut)
        console.log('receive data date = ' + Date())
        console.log('receive data = ' + res)
        var status = '待机'
        if (res.current >= 100){
          status = '充电中'
          if(res.current > 200){
            _animation.rotate(200).step()
          }else{
            _animation.rotate(res.current).step()
          }
        }else if(res.current <= -100){
          status = '放电中'
          if(res.current < -200){
            _animation.rotate(200).step()
          }else{
            _animation.rotate(res.current * -1).step()
          }
        }else{
          _animation.rotate(0).step()
        }
        that.setData ({
          temperature : res.temperature,
          cycleTimes : res.cycle,
          batteryStatus : status,
          voltage : res.voltage,
          batteryCapacity : res.fcc,
          current : res.current,
          soc : res.soc,
          animation: _animation.export()
        })
        canvas.drawCircle("canvasProgressbg",res.soc)
      })
    }
  }
})

// Voltage:无符号(单位 V) 
  // 1、单节(cell)电压范围:0~5000mV(0~5V); 2、总电压等于各单节电压之和。
// Current:有符号，一般正值为充电，负值为放电(单位 A) 
  // 1、通常范围在-200000~200000mA(-200~200A);
  // 2、电流大小在-100~100mA 时，电流表指针不发生偏转，同时电流显示为 0.0A(无符号);
  // 3、电流 >100mA 时，电流表指针正向(顺时针)偏转，电流 <-100mA 时，电流表指针反向(逆时针)
// 偏转，且需在电流前显示“-”号。
// Status:无符号，有 Standby、Discharging、Charging 三种状态
  // 1、电流大小在-100~100mA 时为“Standby”状态，电流<-100mA 时为“Discharging”状态，电流>100mA
// 时为“Charging”状态。 Temperature:无符号，0°C偏移量 2731(单位°C)
//   1、范围在-40°C~80°C，但图形界面量程设置在-20~80°C，小于-20°C时显示实际温度但图形条不再变动。 
// SOC:无符号，电池容量的百分比(单位%)
  // 1、范围 0-100(%)。 
// FCC:无符号，电池的容量(单位 AH)
  // 1、范围 0-1000000mAH(0-1000AH)通常范围在 0-300AH;
  // 2、容量显示精确到小数点后一位有效数字，并对百分位进行四舍五入处理。 
// Cycle Life:无符号，电池的循环次数
  // 1、范围 0~5000，但图形界面量程设置在 0~3000，大于 3000 次时显示实际循环次数但图形条不再变动。 
// Health:有 Perfect、Good 两种状态
  // 1、当循环次数在 0~2000 次时显示“Perfect”，循环次数在 2001~5000 次时显示“Good”。