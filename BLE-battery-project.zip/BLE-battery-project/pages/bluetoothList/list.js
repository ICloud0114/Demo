// pages/bluetoothList/list.js
var Ble = require("../../utils/BluetoothUtil.js")
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    devices: [
    ],
    isDestory: false,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    itemClick: function(event) {
      var deviceId = event.currentTarget.dataset.id
      for (var index in this.data.devices) {
        if (this.data.devices[index].deviceId == deviceId) {
          console.log('选择的蓝牙名-->' + this.data.devices[index].localName + '--')
          var device = this.data.devices[index]
          wx.navigateTo({
            url: '../battery/infomation?device=' + JSON.stringify(device),
          })
        }
      }
    },
    searchingDevices(){
      var that = this
      Ble.openBluetoothAdapter(function(devices) {
        if (that.data.isDestory){
          console.log("data is destory")
          return
        }
        if (devices == '10001') {
          that.connectFailed('蓝牙未开启，请确保设备解锁过程中蓝牙始终打开。蓝牙开启步骤：打开手机设置 -> 找到蓝牙 -> 打开蓝牙')
        }else if(devices == '10001-3'){
          that.connectFailed('蓝牙未授权，请确保您的微信已开启蓝牙使用权限,打开手机设置->隐私->蓝牙->微信开启')
        }else if (devices < 0) {
          wx.showModal({
            title: '提示',
            content: '未搜索到蓝牙设备，请重试！',
            confirmText: '重试',
            cancelText: '取消',
            success: function(res) {
              if (res.cancel) {
                // wx.navigateBack({
                //   detal: 1
                // })
              } else if (res.confirm) {
                that.searchingDevices()
              }
            }
          })
        } else {
          let sortDevice = devices.sort(that.compare('RSSI', false))
          that.setData({
            devices: sortDevice
          })
       }
      })
    },
///根据信号强度排序
    compare: function (property, bol) {
      return function (a, b) {
      var value1 = a[property];
      var value2 = b[property];
      if(bol){
        return value1 - value2;
      }else {
        return value2 - value1;
      }
    }
  },
     /**
     * 连接失败,蓝牙适配器开启失败
     */
    connectFailed(content) {
      wx.showModal({
        title: '',
        content: content,
        showCancel: false,
        confirmText: '知道啦',
        success: function(res) {
          wx.navigateBack({
            detal: 1
          })
        }
      })
    },

    onLoad: function(options){
      console.log("--->onload")
      wx.setNavigationBarTitle({
        title: '设备列表',
      })
      // wx.showLoading({
      //   title: '搜索中..',
      // })
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
      console.log("---蓝牙列表页面显示---")
      this.data.isDestory = false
      this.searchingDevices()
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {
      console.log("---蓝牙列表页面隐藏---")
      this.onDestory()
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {
      this.onDestory()
    },

    onDestory(){
      this.data.isDestory = true
      Ble.clearTimer()
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {
      this.searchingDevices()
      wx.stopPullDownRefresh()
    },
  }
})
